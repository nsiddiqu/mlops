import logging
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import get_settings
from app.routers import predict, health

logging.basicConfig(level=logging.INFO)

settings = get_settings()

app = FastAPI(
    title       = settings.app_title,
    version     = settings.app_version,
    description = """
## Used Car Price Prediction API

Powered by an XGBoost model trained on Craigslist vehicle listings,
served via Databricks Model Serving.

### Endpoints
- **POST /predict** — Single car prediction
- **POST /predict/batch** — Batch prediction (JSON)
- **POST /predict/csv** — Upload CSV → Download CSV with prices
- **GET /health** — Service health check
    """,
    docs_url    = "/docs",
    redoc_url   = "/redoc",
)

# ── CORS (allow React dev server) ──────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins     = ["http://localhost:5173", "http://localhost:3000"],
    allow_credentials = True,
    allow_methods     = ["*"],
    allow_headers     = ["*"],
)

# ── Routers ────────────────────────────────────────────────────────────
app.include_router(health.router)
app.include_router(predict.router)


@app.get("/", include_in_schema=False)
async def root():
    return {"message": "Used Car Price Prediction API", "docs": "/docs"}
