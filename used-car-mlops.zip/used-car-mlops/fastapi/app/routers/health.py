from fastapi import APIRouter, Depends
from app.models import HealthResponse
from app.services.databricks_client import DatabricksServingClient, get_client
from app.config import get_settings

router = APIRouter(tags=["Health"])


@router.get("/health", response_model=HealthResponse)
async def health(client: DatabricksServingClient = Depends(get_client)):
    settings = get_settings()
    endpoint_ok = await client.health_check()
    return HealthResponse(
        status          = "ok" if endpoint_ok else "degraded",
        model_endpoint  = settings.databricks_serving_endpoint,
        version         = settings.app_version,
    )
