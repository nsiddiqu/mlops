import io
import csv
import logging
from typing import List

import pandas as pd
from fastapi import APIRouter, HTTPException, UploadFile, File, Depends
from fastapi.responses import StreamingResponse

from app.models import (
    CarFeatures,
    PredictRequest,
    PredictResponse,
    BatchPredictRequest,
    BatchPredictResponse,
)
from app.services.databricks_client import DatabricksServingClient, get_client

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/predict", tags=["Predictions"])


@router.post("/", response_model=PredictResponse, summary="Predict price for a single car")
async def predict_single(
    request: PredictRequest,
    client: DatabricksServingClient = Depends(get_client),
):
    """
    Predict the price of a single used car.

    Returns estimated price in USD.
    """
    try:
        features = request.features.to_inference_dict()
        price    = await client.predict_single(features)
        return PredictResponse(predicted_price=price)
    except Exception as e:
        logger.exception("Prediction failed")
        raise HTTPException(status_code=502, detail=f"Prediction service error: {str(e)}")


@router.post("/batch", response_model=BatchPredictResponse, summary="Predict prices for multiple cars")
async def predict_batch(
    request: BatchPredictRequest,
    client: DatabricksServingClient = Depends(get_client),
):
    """
    Predict prices for a list of cars (max 5,000 records).
    """
    try:
        records = [r.to_inference_dict() for r in request.records]
        prices  = await client.predict_batch(records)
        return BatchPredictResponse(predictions=prices, count=len(prices))
    except Exception as e:
        logger.exception("Batch prediction failed")
        raise HTTPException(status_code=502, detail=f"Batch prediction service error: {str(e)}")


@router.post(
    "/csv",
    summary="Upload CSV, get CSV with predicted prices",
    response_class=StreamingResponse,
    responses={
        200: {
            "content": {"text/csv": {}},
            "description": "CSV file with appended predicted_price column",
        }
    },
)
async def predict_csv(
    file: UploadFile = File(..., description="CSV file with car features"),
    client: DatabricksServingClient = Depends(get_client),
):
    """
    Upload a CSV file containing car features.
    Returns the same CSV with an added `predicted_price` column.

    **Required columns**: year, manufacturer, model, odometer

    **Optional columns**: condition, fuel, transmission, drive, type, paint_color, state
    """
    # ── Validate file type ──────────────────────────────────────────────
    if not file.filename.endswith(".csv"):
        raise HTTPException(status_code=400, detail="Only CSV files are accepted.")

    content = await file.read()
    try:
        df = pd.read_csv(io.BytesIO(content))
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Could not parse CSV: {e}")

    # ── Validate required columns ───────────────────────────────────────
    required = {"year", "manufacturer", "model", "odometer"}
    missing  = required - set(df.columns.str.lower())
    if missing:
        raise HTTPException(
            status_code=422,
            detail=f"Missing required columns: {', '.join(sorted(missing))}"
        )

    if len(df) > 5000:
        raise HTTPException(status_code=422, detail="CSV cannot exceed 5,000 rows.")

    # ── Normalise column names ──────────────────────────────────────────
    df.columns = df.columns.str.lower().str.strip()

    # ── Fill defaults for optional columns ─────────────────────────────
    OPTIONAL_DEFAULTS = {
        "condition":    "unknown",
        "fuel":         "gas",
        "transmission": "automatic",
        "drive":        "unknown",
        "type":         "unknown",
        "paint_color":  "unknown",
        "state":        "unknown",
    }
    for col, default in OPTIONAL_DEFAULTS.items():
        if col not in df.columns:
            df[col] = default
        else:
            df[col] = df[col].fillna(default).astype(str).str.lower().str.strip()

    # ── Build feature records ───────────────────────────────────────────
    df["car_age"] = 2024 - pd.to_numeric(df["year"], errors="coerce").fillna(0).astype(int)

    FEATURE_COLS = [
        "year", "car_age", "manufacturer", "model", "condition",
        "odometer", "fuel", "transmission", "drive", "type",
        "paint_color", "state"
    ]
    records = df[FEATURE_COLS].to_dict(orient="records")

    # ── Call Databricks in batches of 500 ──────────────────────────────
    CHUNK_SIZE = 500
    all_prices: List[float] = []

    try:
        for i in range(0, len(records), CHUNK_SIZE):
            chunk  = records[i : i + CHUNK_SIZE]
            prices = await client.predict_batch(chunk)
            all_prices.extend(prices)
    except Exception as e:
        logger.exception("CSV batch prediction failed")
        raise HTTPException(status_code=502, detail=f"Prediction service error: {str(e)}")

    # ── Attach predictions to original dataframe ────────────────────────
    df["predicted_price_usd"] = all_prices

    # ── Stream CSV response ─────────────────────────────────────────────
    output = io.StringIO()
    df.to_csv(output, index=False)
    output.seek(0)

    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={
            "Content-Disposition": f'attachment; filename="predictions_{file.filename}"'
        },
    )
