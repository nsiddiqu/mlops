import httpx
import logging
from typing import List, Dict, Any

from app.config import get_settings

logger = logging.getLogger(__name__)


class DatabricksServingClient:
    """
    Thin async client for Databricks Model Serving.
    Uses the standard /invocations endpoint.
    """

    def __init__(self):
        settings = get_settings()
        self.endpoint_url = settings.databricks_serving_endpoint
        self.token        = settings.databricks_token
        self.timeout      = settings.request_timeout_seconds

    @property
    def _headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self.token}",
            "Content-Type":  "application/json",
        }

    async def predict_single(self, features: Dict[str, Any]) -> float:
        """Predict price for a single car."""
        payload = {"dataframe_records": [features]}
        result  = await self._post(payload)
        return round(float(result["predictions"][0]), 2)

    async def predict_batch(self, records: List[Dict[str, Any]]) -> List[float]:
        """Predict prices for a batch of cars."""
        payload = {"dataframe_records": records}
        result  = await self._post(payload)
        return [round(float(p), 2) for p in result["predictions"]]

    async def _post(self, payload: dict) -> dict:
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            try:
                response = await client.post(
                    self.endpoint_url,
                    headers=self._headers,
                    json=payload,
                )
                response.raise_for_status()
                return response.json()
            except httpx.HTTPStatusError as e:
                logger.error(f"Databricks API error {e.response.status_code}: {e.response.text}")
                raise
            except httpx.RequestError as e:
                logger.error(f"Request error: {e}")
                raise

    async def health_check(self) -> bool:
        """Quick connectivity check."""
        try:
            async with httpx.AsyncClient(timeout=5) as client:
                resp = await client.get(
                    self.endpoint_url.replace("/invocations", ""),
                    headers=self._headers,
                )
                return resp.status_code < 500
        except Exception:
            return False


# Singleton
_client: DatabricksServingClient | None = None


def get_client() -> DatabricksServingClient:
    global _client
    if _client is None:
        _client = DatabricksServingClient()
    return _client
