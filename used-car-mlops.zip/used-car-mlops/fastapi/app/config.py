from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    # ── Databricks ─────────────────────────────────────────────────────
    databricks_host: str            # e.g. https://adb-xxxx.azuredatabricks.net
    databricks_token: str           # Personal Access Token or Service Principal
    databricks_serving_endpoint: str  # Full URL to invocations endpoint

    # ── App ────────────────────────────────────────────────────────────
    app_title: str = "Used Car Price Prediction API"
    app_version: str = "1.0.0"
    max_batch_size: int = 5000      # Max rows per CSV upload
    request_timeout_seconds: int = 30

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


@lru_cache
def get_settings() -> Settings:
    return Settings()
