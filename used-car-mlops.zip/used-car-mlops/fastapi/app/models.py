from pydantic import BaseModel, Field, validator
from typing import Optional, List
from enum import Enum


class FuelType(str, Enum):
    gas      = "gas"
    diesel   = "diesel"
    hybrid   = "hybrid"
    electric = "electric"
    other    = "other"
    unknown  = "unknown"


class TransmissionType(str, Enum):
    automatic = "automatic"
    manual    = "manual"
    other     = "other"
    unknown   = "unknown"


class DriveType(str, Enum):
    fwd     = "fwd"
    rwd     = "rwd"
    four_wd = "4wd"
    unknown = "unknown"


class CarFeatures(BaseModel):
    year:         int            = Field(...,  ge=1980, le=2025, example=2019)
    manufacturer: str            = Field(...,  example="honda")
    model:        str            = Field(...,  example="civic")
    condition:    Optional[str]  = Field("unknown", example="good")
    odometer:     float          = Field(...,  ge=0, le=400_000, example=45000)
    fuel:         Optional[str]  = Field("gas",  example="gas")
    transmission: Optional[str]  = Field("automatic", example="automatic")
    drive:        Optional[str]  = Field("unknown", example="fwd")
    type:         Optional[str]  = Field("unknown", example="sedan")
    paint_color:  Optional[str]  = Field("unknown", example="blue")
    state:        Optional[str]  = Field("unknown", example="ca")

    @validator("manufacturer", "model", "condition", "fuel",
               "transmission", "drive", "type", "paint_color", "state",
               pre=True, always=True)
    def lowercase_strip(cls, v):
        if v is None:
            return "unknown"
        return str(v).lower().strip()

    def to_inference_dict(self) -> dict:
        """Add car_age derived feature for model input."""
        d = self.dict()
        d["car_age"] = 2024 - self.year
        return d


class PredictRequest(BaseModel):
    features: CarFeatures


class PredictResponse(BaseModel):
    predicted_price: float
    currency: str = "USD"


class BatchPredictRequest(BaseModel):
    records: List[CarFeatures]

    @validator("records")
    def check_batch_size(cls, v):
        if len(v) > 5000:
            raise ValueError("Batch size cannot exceed 5000 records")
        return v


class BatchPredictResponse(BaseModel):
    predictions:    List[float]
    count:          int
    currency:       str = "USD"


class HealthResponse(BaseModel):
    status:          str
    model_endpoint:  str
    version:         str
