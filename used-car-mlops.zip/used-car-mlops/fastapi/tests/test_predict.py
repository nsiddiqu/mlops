"""
Tests for the prediction API.
Run: pytest tests/ -v
"""
import io
import pytest
from fastapi.testclient import TestClient
from unittest.mock import AsyncMock, patch

# Patch settings before importing app
import os
os.environ["DATABRICKS_HOST"]             = "https://fake.azuredatabricks.net"
os.environ["DATABRICKS_TOKEN"]            = "fake-token"
os.environ["DATABRICKS_SERVING_ENDPOINT"] = "https://fake.azuredatabricks.net/serving-endpoints/test/invocations"

from app.main import app

client = TestClient(app)

MOCK_SINGLE_PRICE = 14500.0
MOCK_BATCH_PRICES = [14500.0, 8200.0, 32100.0]


# ── Fixtures ────────────────────────────────────────────────────────────

@pytest.fixture
def mock_databricks_single():
    with patch(
        "app.services.databricks_client.DatabricksServingClient.predict_single",
        new_callable=AsyncMock,
        return_value=MOCK_SINGLE_PRICE,
    ):
        yield


@pytest.fixture
def mock_databricks_batch():
    with patch(
        "app.services.databricks_client.DatabricksServingClient.predict_batch",
        new_callable=AsyncMock,
        return_value=MOCK_BATCH_PRICES,
    ):
        yield


# ── Health ──────────────────────────────────────────────────────────────

def test_health_endpoint():
    with patch(
        "app.services.databricks_client.DatabricksServingClient.health_check",
        new_callable=AsyncMock,
        return_value=True,
    ):
        resp = client.get("/health")
    assert resp.status_code == 200
    body = resp.json()
    assert body["status"] in ("ok", "degraded")
    assert "model_endpoint" in body


# ── Single prediction ───────────────────────────────────────────────────

def test_predict_single_valid(mock_databricks_single):
    payload = {
        "features": {
            "year": 2019,
            "manufacturer": "honda",
            "model": "civic",
            "condition": "good",
            "odometer": 45000,
            "fuel": "gas",
            "transmission": "automatic",
            "drive": "fwd",
            "type": "sedan",
            "paint_color": "blue",
            "state": "ca",
        }
    }
    resp = client.post("/predict/", json=payload)
    assert resp.status_code == 200
    body = resp.json()
    assert body["predicted_price"] == MOCK_SINGLE_PRICE
    assert body["currency"] == "USD"


def test_predict_single_invalid_year():
    payload = {"features": {"year": 1800, "manufacturer": "ford", "model": "f150", "odometer": 50000}}
    resp = client.post("/predict/", json=payload)
    assert resp.status_code == 422  # Validation error


def test_predict_single_invalid_odometer():
    payload = {"features": {"year": 2020, "manufacturer": "ford", "model": "f150", "odometer": -100}}
    resp = client.post("/predict/", json=payload)
    assert resp.status_code == 422


# ── Batch prediction ────────────────────────────────────────────────────

def test_predict_batch_valid(mock_databricks_batch):
    payload = {
        "records": [
            {"year": 2018, "manufacturer": "toyota", "model": "camry", "odometer": 55000},
            {"year": 2015, "manufacturer": "ford",   "model": "f-150",  "odometer": 120000},
            {"year": 2020, "manufacturer": "bmw",    "model": "3 series", "odometer": 20000},
        ]
    }
    resp = client.post("/predict/batch", json=payload)
    assert resp.status_code == 200
    body = resp.json()
    assert body["count"] == 3
    assert len(body["predictions"]) == 3


# ── CSV prediction ──────────────────────────────────────────────────────

SAMPLE_CSV = """year,manufacturer,model,condition,odometer,fuel,transmission,drive,type,paint_color,state
2019,honda,civic,good,45000,gas,automatic,fwd,sedan,blue,ca
2015,ford,f-150,fair,120000,gas,automatic,4wd,pickup,black,tx
2020,bmw,3 series,excellent,20000,gas,automatic,rwd,sedan,silver,ny
"""

def test_predict_csv_valid(mock_databricks_batch):
    file_bytes = SAMPLE_CSV.encode("utf-8")
    resp = client.post(
        "/predict/csv",
        files={"file": ("cars.csv", io.BytesIO(file_bytes), "text/csv")},
    )
    assert resp.status_code == 200
    assert "text/csv" in resp.headers["content-type"]
    # Check the output has the predicted column
    output = resp.content.decode("utf-8")
    assert "predicted_price_usd" in output


def test_predict_csv_wrong_extension():
    resp = client.post(
        "/predict/csv",
        files={"file": ("cars.txt", io.BytesIO(b"year,make\n2020,honda"), "text/plain")},
    )
    assert resp.status_code == 400


def test_predict_csv_missing_columns():
    bad_csv = b"make,color\nhonda,blue\n"
    resp = client.post(
        "/predict/csv",
        files={"file": ("cars.csv", io.BytesIO(bad_csv), "text/csv")},
    )
    assert resp.status_code == 422
