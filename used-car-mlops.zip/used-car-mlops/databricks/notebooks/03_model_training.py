# Databricks notebook source
# MAGIC %md
# MAGIC # 03 — Model Training
# MAGIC
# MAGIC **Goal**: Train an XGBoost regression model with full MLflow tracking.
# MAGIC All artifacts are logged to an MLflow experiment stored in Unity Catalog.
# MAGIC
# MAGIC Pipeline: `Silver Table → Train/Test Split → XGBoost → MLflow Run`

# COMMAND ----------

# MAGIC %pip install xgboost scikit-learn shap mlflow -q

# COMMAND ----------

# ── Config ──────────────────────────────────────────────────────────────
CATALOG           = "mlops_demo"
SILVER_TABLE      = f"{CATALOG}.silver.used_cars_features"
EXPERIMENT_NAME   = f"/Users/me@company.com/used-car-price-prediction"

# Model registry (Unity Catalog path)
UC_MODEL_NAME     = f"{CATALOG}.silver.used_car_price_model"

TARGET_COL        = "price"
RANDOM_STATE      = 42
TEST_SIZE         = 0.2

print(f"Source   : {SILVER_TABLE}")
print(f"Registry : {UC_MODEL_NAME}")

# COMMAND ----------

import mlflow
import mlflow.xgboost
import numpy as np
import pandas as pd
import shap
import xgboost as xgb
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OrdinalEncoder
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
import matplotlib.pyplot as plt

mlflow.set_registry_uri("databricks-uc")
mlflow.set_experiment(EXPERIMENT_NAME)

# COMMAND ----------

# MAGIC %md ## 1. Load Silver Data

# COMMAND ----------

df = spark.table(SILVER_TABLE).toPandas()
print(f"Rows: {len(df):,}  |  Columns: {df.shape[1]}")
df.head()

# COMMAND ----------

# MAGIC %md ## 2. Preprocessing

# COMMAND ----------

CATEGORICAL_COLS = [
    "manufacturer", "model", "condition", "fuel",
    "transmission", "drive", "type", "paint_color", "state"
]
NUMERIC_COLS = ["year", "car_age", "odometer"]

X = df[CATEGORICAL_COLS + NUMERIC_COLS]
y = df[TARGET_COL]

# ── Encode categoricals with ordinal encoder (handles unseen with "unknown") ──
encoder = OrdinalEncoder(
    handle_unknown="use_encoded_value",
    unknown_value=-1,
    dtype=np.float32
)

preprocessor = ColumnTransformer(
    transformers=[
        ("cat", encoder, CATEGORICAL_COLS),
        ("num", "passthrough", NUMERIC_COLS),
    ]
)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=TEST_SIZE, random_state=RANDOM_STATE
)
print(f"Train: {len(X_train):,}  |  Test: {len(X_test):,}")

# COMMAND ----------

# MAGIC %md ## 3. Train with MLflow Autolog

# COMMAND ----------

# ── Hyperparameters ────────────────────────────────────────────────────
PARAMS = {
    "n_estimators":     500,
    "max_depth":        7,
    "learning_rate":    0.05,
    "subsample":        0.8,
    "colsample_bytree": 0.8,
    "min_child_weight": 5,
    "gamma":            0.1,
    "reg_alpha":        0.1,
    "reg_lambda":       1.0,
    "tree_method":      "hist",   # fast on CPU
    "random_state":     RANDOM_STATE,
    "n_jobs":           -1,
}

with mlflow.start_run(run_name="xgboost-baseline") as run:
    RUN_ID = run.info.run_id
    print(f"MLflow Run ID: {RUN_ID}")

    # ── Log params ──────────────────────────────────────────────────────
    mlflow.log_params(PARAMS)
    mlflow.log_params({
        "train_size":        len(X_train),
        "test_size":         len(X_test),
        "categorical_cols":  str(CATEGORICAL_COLS),
        "numeric_cols":      str(NUMERIC_COLS),
        "target_col":        TARGET_COL,
    })

    # ── Fit pipeline ────────────────────────────────────────────────────
    model = Pipeline([
        ("preprocessor", preprocessor),
        ("regressor", xgb.XGBRegressor(**PARAMS)),
    ])
    model.fit(
        X_train, y_train,
        regressor__eval_set=[(preprocessor.fit_transform(X_test), y_test)],
        regressor__verbose=50,
    )

    # ── Evaluate ────────────────────────────────────────────────────────
    y_pred = model.predict(X_test)

    mae  = mean_absolute_error(y_test, y_pred)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    r2   = r2_score(y_test, y_pred)
    mape = np.mean(np.abs((y_test - y_pred) / y_test)) * 100

    mlflow.log_metrics({
        "mae":  round(mae, 2),
        "rmse": round(rmse, 2),
        "r2":   round(r2, 4),
        "mape": round(mape, 2),
    })

    print(f"\n📊 Metrics:")
    print(f"   MAE  : ${mae:,.0f}")
    print(f"   RMSE : ${rmse:,.0f}")
    print(f"   R²   : {r2:.4f}")
    print(f"   MAPE : {mape:.2f}%")

    # ── Feature importance plot ─────────────────────────────────────────
    feat_names = CATEGORICAL_COLS + NUMERIC_COLS
    importances = model.named_steps["regressor"].feature_importances_
    fi_df = pd.DataFrame({"feature": feat_names, "importance": importances})
    fi_df = fi_df.sort_values("importance", ascending=True).tail(20)

    fig, ax = plt.subplots(figsize=(10, 8))
    ax.barh(fi_df["feature"], fi_df["importance"], color="#4F8EF7")
    ax.set_title("Feature Importances (XGBoost)", fontsize=14)
    ax.set_xlabel("Importance")
    plt.tight_layout()
    mlflow.log_figure(fig, "feature_importance.png")
    plt.close()

    # ── SHAP summary plot (sample 2000 rows for speed) ──────────────────
    X_test_transformed = preprocessor.transform(X_test.sample(2000, random_state=42))
    explainer = shap.TreeExplainer(model.named_steps["regressor"])
    shap_values = explainer.shap_values(X_test_transformed)

    fig2, ax2 = plt.subplots(figsize=(10, 8))
    shap.summary_plot(shap_values, X_test_transformed,
                      feature_names=feat_names, show=False)
    mlflow.log_figure(plt.gcf(), "shap_summary.png")
    plt.close()

    # ── Log model with input example & signature ────────────────────────
    input_example = X_train.head(5)
    signature = mlflow.models.infer_signature(X_train, y_pred[:5])

    mlflow.sklearn.log_model(
        sk_model        = model,
        artifact_path   = "model",
        signature       = signature,
        input_example   = input_example,
        registered_model_name = UC_MODEL_NAME,
    )

    print(f"\n✅ Model logged to MLflow & registered as: {UC_MODEL_NAME}")

# COMMAND ----------

# MAGIC %md ## 4. Residual Analysis

# COMMAND ----------

residuals = y_test - y_pred

fig, axes = plt.subplots(1, 2, figsize=(14, 5))

# Residuals vs Predicted
axes[0].scatter(y_pred, residuals, alpha=0.3, s=5, color="#4F8EF7")
axes[0].axhline(0, color="red", linewidth=1)
axes[0].set_xlabel("Predicted Price ($)")
axes[0].set_ylabel("Residual ($)")
axes[0].set_title("Residuals vs Predicted")

# Actual vs Predicted
axes[1].scatter(y_test, y_pred, alpha=0.3, s=5, color="#4F8EF7")
lims = [max(0, min(y_test.min(), y_pred.min())), max(y_test.max(), y_pred.max())]
axes[1].plot(lims, lims, "r-", linewidth=1)
axes[1].set_xlabel("Actual Price ($)")
axes[1].set_ylabel("Predicted Price ($)")
axes[1].set_title("Actual vs Predicted")

plt.tight_layout()
display(fig)

# COMMAND ----------

# Save run ID for next notebook
dbutils.jobs.taskValues.set(key="run_id",    value=RUN_ID)
dbutils.jobs.taskValues.set(key="model_name", value=UC_MODEL_NAME)

print(f"\n✅ Training complete. Run ID: {RUN_ID}")
print(f"Next step → 04_model_evaluation")
