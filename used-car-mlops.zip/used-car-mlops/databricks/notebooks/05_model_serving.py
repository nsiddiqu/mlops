# Databricks notebook source
# MAGIC %md
# MAGIC # 05 — Model Serving
# MAGIC
# MAGIC **Goal**: Deploy the Champion model to a **Databricks Model Serving** endpoint.
# MAGIC The endpoint will be called by our FastAPI service.

# COMMAND ----------

# MAGIC %pip install databricks-sdk -q

# COMMAND ----------

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.serving import (
    ServedEntityInput,
    EndpointCoreConfigInput,
    AutoCaptureConfigInput,
)
import time

CATALOG           = "mlops_demo"
UC_MODEL_NAME     = f"{CATALOG}.silver.used_car_price_model"
ENDPOINT_NAME     = "used-car-price-prediction"

# Read champion version from previous task
try:
    CHAMPION_VERSION = dbutils.jobs.taskValues.get(
        taskKey="model_evaluation", key="champion_version", debugValue="1"
    )
except:
    CHAMPION_VERSION = "1"

w = WorkspaceClient()
print(f"Deploying model : {UC_MODEL_NAME} v{CHAMPION_VERSION}")
print(f"Endpoint name   : {ENDPOINT_NAME}")

# COMMAND ----------

# MAGIC %md ## 1. Check if endpoint already exists

# COMMAND ----------

existing_endpoints = {e.name for e in w.serving_endpoints.list()}
endpoint_exists    = ENDPOINT_NAME in existing_endpoints
print(f"Endpoint exists: {endpoint_exists}")

# COMMAND ----------

# MAGIC %md ## 2. Create or Update the Serving Endpoint

# COMMAND ----------

served_entity = ServedEntityInput(
    entity_name          = UC_MODEL_NAME,
    entity_version       = str(CHAMPION_VERSION),
    workload_size        = "Small",   # Small | Medium | Large
    scale_to_zero_enabled = True,
    name                 = "current",
)

config = EndpointCoreConfigInput(
    served_entities = [served_entity],
    # Optional: enable inference table for monitoring
    auto_capture_config = AutoCaptureConfigInput(
        catalog_name = CATALOG,
        schema_name  = "silver",
        table_name_prefix = "used_car_predictions",
        enabled      = True,
    ),
)

if endpoint_exists:
    print("Updating existing endpoint...")
    w.serving_endpoints.update_config(
        name   = ENDPOINT_NAME,
        config = config,
    )
else:
    print("Creating new endpoint...")
    w.serving_endpoints.create(
        name   = ENDPOINT_NAME,
        config = config,
    )

# COMMAND ----------

# MAGIC %md ## 3. Wait for endpoint to be ready

# COMMAND ----------

print("Waiting for endpoint to be ready", end="")
max_wait_seconds = 600
elapsed = 0
poll_interval = 15

while elapsed < max_wait_seconds:
    endpoint = w.serving_endpoints.get(ENDPOINT_NAME)
    state    = endpoint.state.ready if endpoint.state else None
    config_state = endpoint.state.config_update if endpoint.state else None

    print(f"\r  State: {state} | Config: {config_state} | Elapsed: {elapsed}s", end="")

    if str(state) == "EndpointStateReady.READY":
        print(f"\n✅ Endpoint '{ENDPOINT_NAME}' is READY!")
        break

    time.sleep(poll_interval)
    elapsed += poll_interval
else:
    print(f"\n⚠️  Timed out after {max_wait_seconds}s. Check the Databricks UI.")

# COMMAND ----------

# MAGIC %md ## 4. Test the Endpoint

# COMMAND ----------

import json

# Sample payload (mirrors FastAPI request body)
test_payload = {
    "dataframe_records": [
        {
            "year": 2019, "car_age": 5, "manufacturer": "honda",
            "model": "civic", "condition": "good", "odometer": 45000,
            "fuel": "gas", "transmission": "automatic", "drive": "fwd",
            "type": "sedan", "paint_color": "blue", "state": "ca"
        }
    ]
}

response = w.serving_endpoints.query(
    name = ENDPOINT_NAME,
    dataframe_records = test_payload["dataframe_records"],
)

print("✅ Test inference result:")
print(json.dumps({"predictions": response.predictions}, indent=2))

# COMMAND ----------

# MAGIC %md ## 5. Print Endpoint URL (for FastAPI config)

# COMMAND ----------

endpoint = w.serving_endpoints.get(ENDPOINT_NAME)
workspace_url = spark.conf.get("spark.databricks.workspaceUrl")

endpoint_url = (
    f"https://{workspace_url}"
    f"/serving-endpoints/{ENDPOINT_NAME}/invocations"
)

print("\n" + "="*60)
print("📋  Copy this URL to your FastAPI .env file:")
print("="*60)
print(f"DATABRICKS_SERVING_ENDPOINT={endpoint_url}")
print("="*60)

dbutils.jobs.taskValues.set(key="endpoint_url", value=endpoint_url)

# COMMAND ----------

# MAGIC %md
# MAGIC ## ✅ Done
# MAGIC
# MAGIC The model is now live at the endpoint above.
# MAGIC
# MAGIC **Next steps:**
# MAGIC 1. Copy `DATABRICKS_SERVING_ENDPOINT` to `fastapi/.env`
# MAGIC 2. Also set `DATABRICKS_TOKEN` in `.env`
# MAGIC 3. Start the FastAPI service: `uvicorn app.main:app --reload`
