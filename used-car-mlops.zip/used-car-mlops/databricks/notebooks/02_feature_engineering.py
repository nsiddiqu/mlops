# Databricks notebook source
# MAGIC %md
# MAGIC # 02 — Feature Engineering
# MAGIC
# MAGIC **Goal**: Clean the Bronze table, engineer features, and write a **Silver** Delta table
# MAGIC that is ready for model training.
# MAGIC
# MAGIC Pipeline: `Bronze (raw) → Silver (clean + engineered)`

# COMMAND ----------

CATALOG        = "mlops_demo"
BRONZE_SCHEMA  = "bronze"
SILVER_SCHEMA  = "silver"
BRONZE_TABLE   = f"{CATALOG}.{BRONZE_SCHEMA}.used_cars_raw"
SILVER_TABLE   = f"{CATALOG}.{SILVER_SCHEMA}.used_cars_features"

print(f"Source : {BRONZE_TABLE}")
print(f"Target : {SILVER_TABLE}")

# COMMAND ----------

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.{SILVER_SCHEMA}")

# COMMAND ----------

# MAGIC %md ## 1. Load Bronze

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import IntegerType, DoubleType

df = spark.table(BRONZE_TABLE)
print(f"Bronze rows: {df.count():,}")

# COMMAND ----------

# MAGIC %md ## 2. Filter & Clean

# COMMAND ----------

# ── Price range: keep $500 – $150,000 ─────────────────────────────────
df = df.filter(F.col("price").cast(DoubleType()).isNotNull())
df = df.withColumn("price", F.col("price").cast(DoubleType()))
df = df.filter((F.col("price") >= 500) & (F.col("price") <= 150_000))

# ── Odometer: keep 0 – 400,000 miles ──────────────────────────────────
df = df.withColumn("odometer", F.col("odometer").cast(DoubleType()))
df = df.filter(F.col("odometer").isNotNull() & (F.col("odometer") <= 400_000))

# ── Year: keep 1980 – current year ────────────────────────────────────
df = df.withColumn("year", F.col("year").cast(IntegerType()))
df = df.filter(F.col("year").isNotNull() & (F.col("year") >= 1980) & (F.col("year") <= 2025))

# ── Drop duplicates ────────────────────────────────────────────────────
df = df.dropDuplicates(["url"])

print(f"After cleaning: {df.count():,}")

# COMMAND ----------

# MAGIC %md ## 3. Feature Engineering

# COMMAND ----------

from pyspark.sql.functions import year as spark_year

CURRENT_YEAR = 2024

# ── Age of the car ─────────────────────────────────────────────────────
df = df.withColumn("car_age", F.lit(CURRENT_YEAR) - F.col("year"))

# ── Price per mile (target leakage check — drop before training) ───────
# Just a QA column, not used as feature
df = df.withColumn(
    "price_per_mile",
    F.when(F.col("odometer") > 0, F.col("price") / F.col("odometer")).otherwise(None)
)

# ── Normalise string categoricals ─────────────────────────────────────
str_cols = ["manufacturer", "model", "condition", "fuel",
            "transmission", "drive", "type", "paint_color", "state"]

for c in str_cols:
    df = df.withColumn(c, F.lower(F.trim(F.col(c))))

# ── Fill nulls in categoricals ─────────────────────────────────────────
for c in str_cols:
    df = df.withColumn(c, F.coalesce(F.col(c), F.lit("unknown")))

# ── Select final feature columns ───────────────────────────────────────
FEATURE_COLS = [
    "year", "car_age", "manufacturer", "model", "condition",
    "odometer", "fuel", "transmission", "drive", "type",
    "paint_color", "state", "price"
]

df_silver = df.select(*FEATURE_COLS)

print(f"Silver rows  : {df_silver.count():,}")
print(f"Silver schema:")
df_silver.printSchema()

# COMMAND ----------

# MAGIC %md ## 4. Write Silver Table

# COMMAND ----------

(
    df_silver.write
             .format("delta")
             .mode("overwrite")
             .option("overwriteSchema", "true")
             .saveAsTable(SILVER_TABLE)
)

print(f"✅ Written to {SILVER_TABLE}")

# COMMAND ----------

# MAGIC %md ## 5. Quick Statistics

# COMMAND ----------

df_silver.describe("price", "odometer", "car_age", "year").show()

# Price distribution by fuel type
(
    df_silver.groupBy("fuel")
             .agg(
                 F.count("*").alias("count"),
                 F.round(F.mean("price"), 0).alias("avg_price"),
                 F.round(F.median("price"), 0).alias("median_price"),
             )
             .orderBy(F.desc("count"))
             .show()
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## ✅ Done
# MAGIC Silver table `{SILVER_TABLE}` is ready for training.
# MAGIC Next step → **03_model_training**
