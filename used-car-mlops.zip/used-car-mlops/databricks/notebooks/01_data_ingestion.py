# Databricks notebook source
# MAGIC %md
# MAGIC # 01 — Data Ingestion
# MAGIC
# MAGIC **Goal**: Download the Used Cars dataset and land it into Unity Catalog as a **Bronze** Delta table.
# MAGIC
# MAGIC Pipeline: `Raw CSV → DBFS → Unity Catalog (Bronze Layer)`

# COMMAND ----------

# MAGIC %md ## 0. Configuration

# COMMAND ----------

# ── Unity Catalog targets ───────────────────────────────────────────────
CATALOG       = "mlops_demo"
BRONZE_SCHEMA = "bronze"
BRONZE_TABLE  = "used_cars_raw"

UC_BRONZE_TABLE = f"{CATALOG}.{BRONZE_SCHEMA}.{BRONZE_TABLE}"

# DBFS staging path
STAGING_PATH  = "dbfs:/tmp/used_cars/vehicles.csv"

print(f"Target table : {UC_BRONZE_TABLE}")

# COMMAND ----------

# MAGIC %md ## 1. Create Catalog & Schema (idempotent)

# COMMAND ----------

spark.sql(f"CREATE CATALOG IF NOT EXISTS {CATALOG}")
spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {BRONZE_SCHEMA}")

print(f"✅ {CATALOG}.{BRONZE_SCHEMA} ready")

# COMMAND ----------

# MAGIC %md ## 2. Download Dataset
# MAGIC
# MAGIC The dataset lives on Kaggle. Two options:
# MAGIC - **Option A** (recommended): Use the Kaggle API inside a Databricks secret scope.
# MAGIC - **Option B**: Manually upload `vehicles.csv` to DBFS and skip this cell.

# COMMAND ----------

import subprocess, os

# ── Option A: Kaggle API (requires KAGGLE_USERNAME / KAGGLE_KEY secrets) ──
try:
    kaggle_user = dbutils.secrets.get(scope="mlops", key="KAGGLE_USERNAME")
    kaggle_key  = dbutils.secrets.get(scope="mlops", key="KAGGLE_KEY")

    os.environ["KAGGLE_USERNAME"] = kaggle_user
    os.environ["KAGGLE_KEY"]      = kaggle_key

    subprocess.run(
        ["pip", "install", "kaggle", "-q"],
        check=True
    )
    subprocess.run(
        [
            "kaggle", "datasets", "download",
            "-d", "austinreese/craigslist-carstrucks-data",
            "--unzip", "-p", "/tmp/used_cars"
        ],
        check=True
    )
    dbutils.fs.cp("file:/tmp/used_cars/vehicles.csv", STAGING_PATH)
    print("✅ Dataset downloaded via Kaggle API")

except Exception as e:
    print(f"⚠️  Kaggle API not available ({e}). Using Option B.")
    print("   Please manually upload vehicles.csv to:", STAGING_PATH)
    # Optionally load a smaller public mirror:
    # spark.read... (add your fallback here)

# COMMAND ----------

# MAGIC %md ## 3. Read CSV → Bronze Delta Table

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *

df_raw = (
    spark.read
         .option("header", "true")
         .option("inferSchema", "true")
         .option("multiLine", "true")
         .option("escape", '"')
         .csv(STAGING_PATH)
)

# Add ingestion metadata
df_raw = (
    df_raw
    .withColumn("_ingested_at", F.current_timestamp())
    .withColumn("_source_file", F.lit(STAGING_PATH))
)

print(f"Rows   : {df_raw.count():,}")
print(f"Columns: {len(df_raw.columns)}")
df_raw.printSchema()

# COMMAND ----------

# MAGIC %md ## 4. Write to Unity Catalog Bronze

# COMMAND ----------

(
    df_raw.write
          .format("delta")
          .mode("overwrite")
          .option("overwriteSchema", "true")
          .saveAsTable(UC_BRONZE_TABLE)
)

print(f"✅ Written to {UC_BRONZE_TABLE}")

# COMMAND ----------

# Quick validation
spark.sql(f"SELECT COUNT(*) AS total_rows FROM {UC_BRONZE_TABLE}").show()
spark.sql(f"""
    SELECT year, manufacturer, model, condition, odometer, fuel,
           transmission, drive, type, paint_color, state, price
    FROM {UC_BRONZE_TABLE}
    LIMIT 5
""").show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ## ✅ Done
# MAGIC Bronze table `{UC_BRONZE_TABLE}` is ready.
# MAGIC Next step → **02_feature_engineering**
