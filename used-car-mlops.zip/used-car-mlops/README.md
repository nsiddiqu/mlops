# 🚗 Used Car Price Prediction — MLOps Pipeline

End-to-end MLOps project using **Databricks**, **Unity Catalog**, **MLflow**, **FastAPI**, and **React**.

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                     DATABRICKS WORKSPACE                        │
│                                                                 │
│  [01_data_ingestion] → [02_feature_engineering]                 │
│         ↓                        ↓                             │
│  Unity Catalog (Bronze)   Unity Catalog (Silver)               │
│                                  ↓                             │
│                      [03_model_training]                        │
│                              ↓                                  │
│                      MLflow Experiment                          │
│                              ↓                                  │
│                      [04_model_evaluation]                      │
│                              ↓                                  │
│                  Unity Catalog Model Registry                   │
│                              ↓                                  │
│                      [05_model_serving]                         │
│                      (Databricks Endpoint)                      │
└─────────────────────────────────────────────────────────────────┘
                               ↓
┌─────────────────────────────────────────────────────────────────┐
│                        FastAPI SERVICE                          │
│   POST /predict  ←→  Databricks Serving Endpoint               │
│   POST /predict/batch  ←→  Process CSV files                   │
└─────────────────────────────────────────────────────────────────┘
                               ↓
┌─────────────────────────────────────────────────────────────────┐
│                      REACT FRONTEND                             │
│   Upload CSV → Call API → Show Results → Download CSV          │
└─────────────────────────────────────────────────────────────────┘
```

## Project Structure

```
used-car-mlops/
├── databricks/
│   ├── notebooks/
│   │   ├── 01_data_ingestion.py         # Kaggle → Unity Catalog Bronze
│   │   ├── 02_feature_engineering.py    # Bronze → Silver (cleaned features)
│   │   ├── 03_model_training.py         # Train XGBoost + MLflow tracking
│   │   ├── 04_model_evaluation.py       # Evaluate & register to UC
│   │   └── 05_model_serving.py          # Deploy Databricks serving endpoint
│   └── jobs/
│       └── mlops_pipeline_job.json      # Databricks Workflow definition
├── fastapi/
│   ├── app/
│   │   ├── main.py                      # FastAPI app entry point
│   │   ├── config.py                    # Settings (env vars)
│   │   ├── models.py                    # Pydantic schemas
│   │   ├── routers/
│   │   │   ├── predict.py               # /predict endpoints
│   │   │   └── health.py                # /health endpoint
│   │   └── services/
│   │       └── databricks_client.py     # Databricks endpoint client
│   ├── tests/
│   │   └── test_predict.py
│   ├── Dockerfile
│   └── requirements.txt
└── frontend/
    ├── src/
    │   ├── App.jsx
    │   ├── components/
    │   │   ├── FileUpload.jsx
    │   │   ├── ResultsTable.jsx
    │   │   └── StatusBanner.jsx
    │   ├── hooks/
    │   │   └── usePrediction.js
    │   └── utils/
    │       └── csvParser.js
    ├── package.json
    └── vite.config.js
```

## Quick Start

### 1. Databricks Setup
```bash
# Install Databricks CLI
pip install databricks-cli

# Configure workspace
databricks configure --token

# Import notebooks
databricks workspace import_dir ./databricks/notebooks /Shared/used-car-mlops
```

### 2. Run the Pipeline (in order)
```
01 → 02 → 03 → 04 → 05
```
Or trigger the full Databricks Workflow:
```bash
databricks jobs create --json @databricks/jobs/mlops_pipeline_job.json
databricks jobs run-now --job-id <JOB_ID>
```

### 3. FastAPI Service
```bash
cd fastapi
pip install -r requirements.txt
uvicorn app.main:app --reload
```

### 4. Frontend
```bash
cd frontend
npm install
npm run dev
```

---

## Dataset
[Used Cars Dataset — Kaggle](https://www.kaggle.com/datasets/austinreese/craigslist-carstrucks-data)

Key features: `year`, `manufacturer`, `model`, `condition`, `odometer`, `fuel`, `transmission`, `drive`, `type`, `paint_color`, `state`

Target: `price` (USD)
