/**
 * Validates a CSV file before uploading.
 * Returns { valid, error, rowCount, headers }
 */
export async function validateCSV(file) {
  if (!file) return { valid: false, error: "No file selected." };
  if (!file.name.endsWith(".csv")) return { valid: false, error: "File must be a .csv" };
  if (file.size > 20 * 1024 * 1024) return { valid: false, error: "File must be under 20 MB." };

  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const text    = e.target.result;
      const lines   = text.trim().split("\n");
      const headers = lines[0].toLowerCase().split(",").map((h) => h.trim().replace(/"/g, ""));
      const rowCount = lines.length - 1;

      const required = ["year", "manufacturer", "model", "odometer"];
      const missing  = required.filter((r) => !headers.includes(r));

      if (missing.length > 0) {
        resolve({ valid: false, error: `Missing required columns: ${missing.join(", ")}` });
        return;
      }
      if (rowCount === 0) {
        resolve({ valid: false, error: "CSV has no data rows." });
        return;
      }
      if (rowCount > 5000) {
        resolve({ valid: false, error: `CSV has ${rowCount.toLocaleString()} rows. Max is 5,000.` });
        return;
      }

      resolve({ valid: true, error: null, rowCount, headers });
    };
    reader.readAsText(file);
  });
}

/**
 * Format a number as USD currency.
 */
export function formatUSD(value) {
  return new Intl.NumberFormat("en-US", {
    style: "currency", currency: "USD", maximumFractionDigits: 0,
  }).format(value);
}
