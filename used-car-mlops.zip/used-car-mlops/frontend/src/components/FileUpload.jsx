import React, { useState } from "react";
import { useDropzone } from "react-dropzone";
import { Upload, FileText, AlertCircle, CheckCircle2 } from "lucide-react";
import { validateCSV } from "../utils/csvParser";

const styles = {
  wrapper: {
    width: "100%",
  },
  zone: (isDragActive, hasError) => ({
    border: `2px dashed ${hasError ? "var(--red)" : isDragActive ? "var(--accent)" : "var(--border)"}`,
    borderRadius: "var(--radius)",
    padding: "48px 32px",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    gap: "16px",
    cursor: "pointer",
    background: isDragActive ? "rgba(232,255,71,0.04)" : "var(--surface)",
    transition: "all 0.2s ease",
    textAlign: "center",
  }),
  icon: (isDragActive) => ({
    color: isDragActive ? "var(--accent)" : "var(--text-muted)",
    transition: "color 0.2s",
  }),
  title: {
    fontFamily: "var(--font-display)",
    fontSize: "18px",
    fontWeight: 600,
    color: "var(--text)",
  },
  subtitle: {
    color: "var(--text-muted)",
    fontSize: "13px",
  },
  accent: {
    color: "var(--accent)",
    fontWeight: 600,
  },
  fileInfo: {
    display: "flex",
    alignItems: "center",
    gap: "12px",
    padding: "12px 16px",
    background: "var(--surface2)",
    borderRadius: "8px",
    marginTop: "16px",
    border: "1px solid var(--border)",
  },
  fileName: {
    fontFamily: "var(--font-mono)",
    fontSize: "13px",
    color: "var(--text)",
    flex: 1,
    overflow: "hidden",
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
  },
  badge: (valid) => ({
    fontSize: "11px",
    fontWeight: 600,
    padding: "3px 8px",
    borderRadius: "4px",
    background: valid ? "rgba(77,255,160,0.15)" : "rgba(255,77,106,0.15)",
    color: valid ? "var(--green)" : "var(--red)",
    whiteSpace: "nowrap",
  }),
  error: {
    display: "flex",
    alignItems: "center",
    gap: "8px",
    color: "var(--red)",
    fontSize: "13px",
    marginTop: "10px",
  },
  hint: {
    fontSize: "12px",
    color: "var(--text-muted)",
    marginTop: "16px",
    lineHeight: "1.7",
  },
  mono: {
    fontFamily: "var(--font-mono)",
    background: "var(--surface2)",
    padding: "1px 5px",
    borderRadius: "3px",
    fontSize: "11px",
  },
  btn: (disabled) => ({
    marginTop: "24px",
    width: "100%",
    padding: "14px 0",
    background: disabled ? "var(--border)" : "var(--accent)",
    color: disabled ? "var(--text-muted)" : "#000",
    border: "none",
    borderRadius: "var(--radius)",
    fontFamily: "var(--font-display)",
    fontSize: "15px",
    fontWeight: 700,
    cursor: disabled ? "not-allowed" : "pointer",
    letterSpacing: "0.5px",
    transition: "all 0.2s",
  }),
};

export default function FileUpload({ onSubmit, disabled }) {
  const [file,       setFile]       = useState(null);
  const [validation, setValidation] = useState(null); // { valid, error, rowCount }
  const [checking,   setChecking]   = useState(false);

  const onDrop = async (accepted) => {
    if (!accepted.length) return;
    const f = accepted[0];
    setFile(f);
    setChecking(true);
    const result = await validateCSV(f);
    setValidation(result);
    setChecking(false);
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { "text/csv": [".csv"] },
    multiple: false,
    disabled,
  });

  const handleSubmit = () => {
    if (file && validation?.valid && !disabled) {
      onSubmit(file);
    }
  };

  const canSubmit = file && validation?.valid && !disabled && !checking;

  return (
    <div style={styles.wrapper}>
      <div {...getRootProps()} style={styles.zone(isDragActive, validation && !validation.valid)}>
        <input {...getInputProps()} />
        <Upload size={40} style={styles.icon(isDragActive)} />
        <div>
          <div style={styles.title}>
            {isDragActive ? "Drop it here" : "Upload your CSV"}
          </div>
          <div style={styles.subtitle}>
            Drag & drop or <span style={styles.accent}>browse files</span>
          </div>
        </div>
      </div>

      {/* File info */}
      {file && (
        <div style={styles.fileInfo}>
          <FileText size={16} color="var(--text-muted)" />
          <span style={styles.fileName}>{file.name}</span>
          {checking ? (
            <span style={styles.badge(true)}>Checking…</span>
          ) : validation?.valid ? (
            <>
              <span style={styles.badge(true)}>
                <CheckCircle2 size={10} style={{ marginRight: 4, verticalAlign: "middle" }} />
                {validation.rowCount.toLocaleString()} rows
              </span>
            </>
          ) : (
            <span style={styles.badge(false)}>Invalid</span>
          )}
        </div>
      )}

      {/* Error message */}
      {validation && !validation.valid && (
        <div style={styles.error}>
          <AlertCircle size={14} />
          {validation.error}
        </div>
      )}

      {/* Column hint */}
      <div style={styles.hint}>
        <strong style={{ color: "var(--text)" }}>Required columns:</strong>{" "}
        {["year", "manufacturer", "model", "odometer"].map((c) => (
          <span key={c}><span style={styles.mono}>{c}</span>{" "}</span>
        ))}
        <br />
        <strong style={{ color: "var(--text)" }}>Optional:</strong>{" "}
        {["condition", "fuel", "transmission", "drive", "type", "paint_color", "state"].map((c) => (
          <span key={c}><span style={styles.mono}>{c}</span>{" "}</span>
        ))}
      </div>

      <button style={styles.btn(!canSubmit)} onClick={handleSubmit} disabled={!canSubmit}>
        {disabled ? "Processing…" : "Predict Prices →"}
      </button>
    </div>
  );
}
