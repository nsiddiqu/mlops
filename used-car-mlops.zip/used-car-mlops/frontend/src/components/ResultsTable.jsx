import React, { useState, useEffect } from "react";
import Papa from "papaparse";
import { Download, TrendingUp, TrendingDown, Minus } from "lucide-react";
import { formatUSD } from "../utils/csvParser";

const styles = {
  section: {
    marginTop: "32px",
  },
  header: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: "20px",
    flexWrap: "wrap",
    gap: "12px",
  },
  title: {
    fontFamily: "var(--font-display)",
    fontSize: "20px",
    fontWeight: 700,
    color: "var(--text)",
  },
  stats: {
    display: "flex",
    gap: "16px",
    flexWrap: "wrap",
  },
  stat: {
    padding: "8px 14px",
    background: "var(--surface2)",
    borderRadius: "8px",
    border: "1px solid var(--border)",
    textAlign: "center",
  },
  statVal: {
    fontFamily: "var(--font-mono)",
    fontSize: "16px",
    fontWeight: 600,
    color: "var(--accent)",
    display: "block",
  },
  statLabel: {
    fontSize: "11px",
    color: "var(--text-muted)",
    textTransform: "uppercase",
    letterSpacing: "0.5px",
  },
  tableWrap: {
    overflowX: "auto",
    borderRadius: "var(--radius)",
    border: "1px solid var(--border)",
  },
  table: {
    width: "100%",
    borderCollapse: "collapse",
    fontSize: "13px",
  },
  th: {
    padding: "12px 14px",
    textAlign: "left",
    fontFamily: "var(--font-display)",
    fontSize: "11px",
    fontWeight: 600,
    textTransform: "uppercase",
    letterSpacing: "0.6px",
    color: "var(--text-muted)",
    background: "var(--surface2)",
    borderBottom: "1px solid var(--border)",
    whiteSpace: "nowrap",
  },
  td: (i) => ({
    padding: "11px 14px",
    borderBottom: "1px solid var(--border)",
    background: i % 2 === 0 ? "var(--surface)" : "transparent",
    fontFamily: "var(--font-body)",
    color: "var(--text)",
    whiteSpace: "nowrap",
  }),
  priceCell: {
    fontFamily: "var(--font-mono)",
    fontWeight: 600,
    color: "var(--accent)",
    fontSize: "14px",
  },
  paginationRow: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: "16px",
    fontSize: "13px",
    color: "var(--text-muted)",
  },
  pageBtn: (disabled) => ({
    padding: "6px 14px",
    background: disabled ? "var(--border)" : "var(--surface2)",
    border: "1px solid var(--border)",
    borderRadius: "6px",
    color: disabled ? "var(--text-muted)" : "var(--text)",
    cursor: disabled ? "not-allowed" : "pointer",
    fontSize: "13px",
    fontFamily: "var(--font-mono)",
  }),
  downloadBtn: {
    display: "flex",
    alignItems: "center",
    gap: "8px",
    padding: "12px 24px",
    background: "var(--accent)",
    color: "#000",
    border: "none",
    borderRadius: "var(--radius)",
    fontFamily: "var(--font-display)",
    fontSize: "15px",
    fontWeight: 700,
    cursor: "pointer",
    letterSpacing: "0.3px",
    transition: "opacity 0.2s",
    marginTop: "20px",
    width: "100%",
    justifyContent: "center",
  },
};

const PAGE_SIZE = 20;

// Columns to always show (priority)
const PRIORITY_COLS = ["year", "manufacturer", "model", "condition", "odometer", "predicted_price_usd"];
const MAX_DISPLAY_COLS = 8;

function pickColumns(headers) {
  const priority = PRIORITY_COLS.filter((c) => headers.includes(c));
  const rest = headers.filter((c) => !priority.includes(c) && c !== "car_age");
  return [...priority, ...rest].slice(0, MAX_DISPLAY_COLS);
}

export default function ResultsTable({ resultBlob, onDownload, rowCount }) {
  const [rows,    setRows]    = useState([]);
  const [headers, setHeaders] = useState([]);
  const [page,    setPage]    = useState(0);
  const [stats,   setStats]   = useState(null);

  useEffect(() => {
    if (!resultBlob) return;
    resultBlob.text().then((text) => {
      const parsed = Papa.parse(text, { header: true, skipEmptyLines: true });
      const data   = parsed.data;
      setRows(data);
      if (data.length > 0) {
        const cols = pickColumns(Object.keys(data[0]));
        setHeaders(cols);

        const prices = data
          .map((r) => parseFloat(r.predicted_price_usd))
          .filter((v) => !isNaN(v));
        if (prices.length) {
          setStats({
            avg: prices.reduce((a, b) => a + b, 0) / prices.length,
            min: Math.min(...prices),
            max: Math.max(...prices),
            total: prices.length,
          });
        }
      }
    });
  }, [resultBlob]);

  if (!rows.length) return null;

  const totalPages  = Math.ceil(rows.length / PAGE_SIZE);
  const displayRows = rows.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);

  const formatCell = (col, val) => {
    if (col === "predicted_price_usd") return formatUSD(parseFloat(val) || 0);
    if (col === "odometer") return parseFloat(val) ? `${parseInt(val).toLocaleString()} mi` : val;
    return val ?? "—";
  };

  return (
    <div style={styles.section}>
      <div style={styles.header}>
        <span style={styles.title}>Prediction Results</span>
        {stats && (
          <div style={styles.stats}>
            <div style={styles.stat}>
              <span style={styles.statVal}>{formatUSD(stats.avg)}</span>
              <span style={styles.statLabel}>Avg Price</span>
            </div>
            <div style={styles.stat}>
              <span style={styles.statVal}>{formatUSD(stats.min)}</span>
              <span style={styles.statLabel}>Min</span>
            </div>
            <div style={styles.stat}>
              <span style={styles.statVal}>{formatUSD(stats.max)}</span>
              <span style={styles.statLabel}>Max</span>
            </div>
            <div style={styles.stat}>
              <span style={styles.statVal}>{stats.total.toLocaleString()}</span>
              <span style={styles.statLabel}>Cars</span>
            </div>
          </div>
        )}
      </div>

      <div style={styles.tableWrap}>
        <table style={styles.table}>
          <thead>
            <tr>
              {headers.map((h) => (
                <th key={h} style={styles.th}>
                  {h === "predicted_price_usd" ? "Predicted Price" : h.replace(/_/g, " ")}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {displayRows.map((row, i) => (
              <tr key={i}>
                {headers.map((h) => (
                  <td
                    key={h}
                    style={{
                      ...styles.td(i),
                      ...(h === "predicted_price_usd" ? styles.priceCell : {}),
                    }}
                  >
                    {formatCell(h, row[h])}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {totalPages > 1 && (
        <div style={styles.paginationRow}>
          <button
            style={styles.pageBtn(page === 0)}
            onClick={() => setPage((p) => p - 1)}
            disabled={page === 0}
          >← Prev</button>
          <span>Page {page + 1} of {totalPages} &nbsp;·&nbsp; {rows.length.toLocaleString()} rows</span>
          <button
            style={styles.pageBtn(page === totalPages - 1)}
            onClick={() => setPage((p) => p + 1)}
            disabled={page === totalPages - 1}
          >Next →</button>
        </div>
      )}

      <button style={styles.downloadBtn} onClick={onDownload}>
        <Download size={18} />
        Download Full CSV with Prices
      </button>
    </div>
  );
}
