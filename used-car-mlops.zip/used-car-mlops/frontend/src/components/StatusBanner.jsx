import React, { useEffect, useState } from "react";
import { Loader2, CheckCircle2, XCircle } from "lucide-react";

const STAGES = [
  { at: 0,  label: "Reading file…" },
  { at: 15, label: "Uploading to API…" },
  { at: 40, label: "Sending to Databricks…" },
  { at: 60, label: "Running inference…" },
  { at: 85, label: "Assembling results…" },
  { at: 98, label: "Finalising…" },
];

function getStageLabel(progress) {
  let label = STAGES[0].label;
  for (const s of STAGES) {
    if (progress >= s.at) label = s.label;
  }
  return label;
}

const styles = {
  banner: (status) => ({
    borderRadius: "var(--radius)",
    padding: "24px 28px",
    border: "1px solid",
    borderColor:
      status === "done"  ? "rgba(77,255,160,0.3)"  :
      status === "error" ? "rgba(255,77,106,0.3)"  :
      "var(--border)",
    background:
      status === "done"  ? "rgba(77,255,160,0.05)" :
      status === "error" ? "rgba(255,77,106,0.05)" :
      "var(--surface)",
    transition: "all 0.3s ease",
  }),
  top: {
    display: "flex",
    alignItems: "center",
    gap: "12px",
    marginBottom: "12px",
  },
  label: (status) => ({
    fontFamily: "var(--font-display)",
    fontSize: "16px",
    fontWeight: 600,
    color:
      status === "done"  ? "var(--green)"  :
      status === "error" ? "var(--red)"    :
      "var(--text)",
  }),
  subLabel: {
    fontSize: "13px",
    color: "var(--text-muted)",
    fontFamily: "var(--font-mono)",
    marginLeft: "auto",
  },
  track: {
    height: "6px",
    background: "var(--border)",
    borderRadius: "3px",
    overflow: "hidden",
  },
  bar: (progress, status) => ({
    height: "100%",
    width: `${progress}%`,
    borderRadius: "3px",
    background:
      status === "done"  ? "var(--green)"  :
      status === "error" ? "var(--red)"    :
      "var(--accent)",
    transition: "width 0.4s ease",
    boxShadow:
      status === "done"  ? "0 0 12px rgba(77,255,160,0.5)"  :
      status !== "error" ? "0 0 12px rgba(232,255,71,0.4)"  :
      "none",
  }),
  errorMsg: {
    fontSize: "13px",
    color: "var(--red)",
    marginTop: "10px",
    fontFamily: "var(--font-mono)",
  },
};

export default function StatusBanner({ status, progress, error, rowCount }) {
  const [displayProgress, setDisplayProgress] = useState(0);

  // Smooth progress animation
  useEffect(() => {
    setDisplayProgress(progress);
  }, [progress]);

  if (status === "idle") return null;

  const isLoading = status === "uploading" || status === "processing";
  const isDone    = status === "done";
  const isError   = status === "error";

  return (
    <div style={styles.banner(status)}>
      <div style={styles.top}>
        {isLoading && (
          <Loader2
            size={18}
            color="var(--accent)"
            style={{ animation: "spin 1s linear infinite" }}
          />
        )}
        {isDone  && <CheckCircle2 size={18} color="var(--green)" />}
        {isError && <XCircle     size={18} color="var(--red)"   />}

        <span style={styles.label(status)}>
          {isDone  ? `Done — ${rowCount.toLocaleString()} predictions ready`       : ""}
          {isError ? "Something went wrong"                                         : ""}
          {isLoading ? getStageLabel(displayProgress)                              : ""}
        </span>

        {isLoading && (
          <span style={styles.subLabel}>{displayProgress}%</span>
        )}
      </div>

      <div style={styles.track}>
        <div style={styles.bar(displayProgress, status)} />
      </div>

      {isError && error && (
        <div style={styles.errorMsg}>⚠ {error}</div>
      )}

      <style>{`
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}
