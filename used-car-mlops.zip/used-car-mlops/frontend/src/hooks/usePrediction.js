import { useState, useCallback } from "react";
import axios from "axios";

const API_BASE = "/predict";

export function usePrediction() {
  const [status, setStatus]         = useState("idle");     // idle | uploading | processing | done | error
  const [progress, setProgress]     = useState(0);
  const [error, setError]           = useState(null);
  const [resultFile, setResultFile] = useState(null);       // Blob
  const [resultName, setResultName] = useState("");
  const [rowCount, setRowCount]     = useState(0);

  const predict = useCallback(async (file) => {
    setStatus("uploading");
    setError(null);
    setResultFile(null);
    setProgress(0);

    const formData = new FormData();
    formData.append("file", file);

    try {
      setStatus("processing");

      const response = await axios.post(`${API_BASE}/csv`, formData, {
        responseType: "blob",
        headers: { "Content-Type": "multipart/form-data" },
        onUploadProgress: (e) => {
          const pct = Math.round((e.loaded / e.total) * 40);
          setProgress(pct);
        },
        onDownloadProgress: (e) => {
          if (e.total) {
            const pct = 40 + Math.round((e.loaded / e.total) * 55);
            setProgress(pct);
          } else {
            setProgress((p) => Math.min(p + 5, 95));
          }
        },
      });

      const blob       = new Blob([response.data], { type: "text/csv" });
      const outputName = `predictions_${file.name}`;

      // Count rows from the blob (approximate via text)
      const text  = await blob.text();
      const lines = text.trim().split("\n").length - 1; // minus header
      setRowCount(lines);

      setResultFile(blob);
      setResultName(outputName);
      setProgress(100);
      setStatus("done");
    } catch (err) {
      let message = "Prediction failed. Please try again.";
      if (err.response) {
        try {
          const text = await err.response.data.text();
          const json = JSON.parse(text);
          message = json.detail || message;
        } catch {}
      }
      setError(message);
      setStatus("error");
    }
  }, []);

  const download = useCallback(() => {
    if (!resultFile) return;
    const url  = URL.createObjectURL(resultFile);
    const link = document.createElement("a");
    link.href     = url;
    link.download = resultName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }, [resultFile, resultName]);

  const reset = useCallback(() => {
    setStatus("idle");
    setProgress(0);
    setError(null);
    setResultFile(null);
    setResultName("");
    setRowCount(0);
  }, []);

  return { status, progress, error, resultFile, resultName, rowCount, predict, download, reset };
}
