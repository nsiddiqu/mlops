import React from "react";
import { usePrediction } from "./hooks/usePrediction";
import FileUpload   from "./components/FileUpload";
import StatusBanner from "./components/StatusBanner";
import ResultsTable from "./components/ResultsTable";
import { RotateCcw, Zap, Database, Cpu } from "lucide-react";

const s = {
  page: {
    minHeight: "100vh",
    background: "var(--bg)",
    padding: "0 0 80px",
  },
  hero: {
    background: "var(--surface)",
    borderBottom: "1px solid var(--border)",
    padding: "48px 0 40px",
    marginBottom: "40px",
    position: "relative",
    overflow: "hidden",
  },
  heroBg: {
    position: "absolute",
    inset: 0,
    background: "radial-gradient(ellipse 60% 80% at 50% -20%, rgba(232,255,71,0.07) 0%, transparent 70%)",
    pointerEvents: "none",
  },
  heroInner: {
    maxWidth: "780px",
    margin: "0 auto",
    padding: "0 24px",
    position: "relative",
    zIndex: 1,
  },
  eyebrow: {
    display: "inline-flex",
    alignItems: "center",
    gap: "6px",
    padding: "4px 12px",
    background: "rgba(232,255,71,0.1)",
    border: "1px solid rgba(232,255,71,0.2)",
    borderRadius: "999px",
    fontSize: "11px",
    fontFamily: "var(--font-mono)",
    color: "var(--accent)",
    letterSpacing: "0.8px",
    textTransform: "uppercase",
    marginBottom: "20px",
  },
  h1: {
    fontFamily: "var(--font-display)",
    fontSize: "clamp(32px, 5vw, 52px)",
    fontWeight: 800,
    lineHeight: 1.1,
    color: "var(--text)",
    marginBottom: "16px",
  },
  accentWord: {
    color: "var(--accent)",
  },
  tagline: {
    color: "var(--text-muted)",
    fontSize: "15px",
    maxWidth: "520px",
    lineHeight: 1.7,
    marginBottom: "28px",
  },
  pipeline: {
    display: "flex",
    alignItems: "center",
    gap: "8px",
    flexWrap: "wrap",
  },
  pill: {
    display: "flex",
    alignItems: "center",
    gap: "5px",
    padding: "5px 12px",
    background: "var(--surface2)",
    border: "1px solid var(--border)",
    borderRadius: "999px",
    fontSize: "12px",
    fontFamily: "var(--font-mono)",
    color: "var(--text-muted)",
  },
  dividerDot: {
    color: "var(--border)",
    fontSize: "18px",
    lineHeight: 1,
  },
  main: {
    maxWidth: "780px",
    margin: "0 auto",
    padding: "0 24px",
  },
  card: {
    background: "var(--surface)",
    border: "1px solid var(--border)",
    borderRadius: "var(--radius)",
    padding: "32px",
    marginBottom: "24px",
  },
  cardTitle: {
    fontFamily: "var(--font-display)",
    fontSize: "14px",
    fontWeight: 600,
    color: "var(--text-muted)",
    textTransform: "uppercase",
    letterSpacing: "0.8px",
    marginBottom: "24px",
    display: "flex",
    alignItems: "center",
    gap: "8px",
  },
  stepNum: {
    width: "22px",
    height: "22px",
    borderRadius: "50%",
    background: "var(--accent)",
    color: "#000",
    fontSize: "11px",
    fontWeight: 800,
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
  },
  resetBtn: {
    display: "flex",
    alignItems: "center",
    gap: "7px",
    padding: "8px 16px",
    background: "transparent",
    border: "1px solid var(--border)",
    borderRadius: "8px",
    color: "var(--text-muted)",
    cursor: "pointer",
    fontSize: "13px",
    fontFamily: "var(--font-mono)",
    marginBottom: "20px",
    transition: "all 0.2s",
  },
};

export default function App() {
  const { status, progress, error, resultFile, rowCount, predict, download, reset } = usePrediction();

  const isProcessing = status === "uploading" || status === "processing";
  const isDone       = status === "done";
  const isError      = status === "error";
  const showReset    = isDone || isError;

  return (
    <div style={s.page}>
      {/* Hero */}
      <div style={s.hero}>
        <div style={s.heroBg} />
        <div style={s.heroInner}>
          <div style={s.eyebrow}>
            <Zap size={10} />
            MLOps · Databricks · Unity Catalog
          </div>
          <h1 style={s.h1}>
            Used Car Price<br />
            <span style={s.accentWord}>Prediction</span>
          </h1>
          <p style={s.tagline}>
            Upload a CSV of used cars. Our XGBoost model — trained on 400k+
            listings and served via Databricks — returns price estimates in seconds.
          </p>
          <div style={s.pipeline}>
            {[
              { icon: <Database size={11} />, label: "Unity Catalog" },
              null,
              { icon: <Cpu size={11} />,      label: "XGBoost" },
              null,
              { icon: <Zap size={11} />,      label: "Databricks Serving" },
              null,
              { icon: null,                   label: "FastAPI" },
            ].map((item, i) =>
              item === null ? (
                <span key={i} style={s.dividerDot}>›</span>
              ) : (
                <span key={i} style={s.pill}>
                  {item.icon}
                  {item.label}
                </span>
              )
            )}
          </div>
        </div>
      </div>

      {/* Main content */}
      <div style={s.main}>
        {/* Reset button */}
        {showReset && (
          <button style={s.resetBtn} onClick={reset}>
            <RotateCcw size={13} />
            Start over
          </button>
        )}

        {/* Upload card — hide when done */}
        {!isDone && (
          <div style={s.card}>
            <div style={s.cardTitle}>
              <span style={s.stepNum}>1</span>
              Upload CSV File
            </div>
            <FileUpload onSubmit={predict} disabled={isProcessing} />
          </div>
        )}

        {/* Status banner */}
        {status !== "idle" && (
          <div style={{ marginBottom: "24px" }}>
            <StatusBanner
              status={status}
              progress={progress}
              error={error}
              rowCount={rowCount}
            />
          </div>
        )}

        {/* Results */}
        {isDone && resultFile && (
          <div style={s.card}>
            <div style={s.cardTitle}>
              <span style={s.stepNum}>2</span>
              Results
            </div>
            <ResultsTable
              resultBlob={resultFile}
              onDownload={download}
              rowCount={rowCount}
            />
          </div>
        )}
      </div>
    </div>
  );
}
