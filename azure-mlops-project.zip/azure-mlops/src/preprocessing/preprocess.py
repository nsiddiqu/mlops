"""
Data Preprocessing Component
Azure ML MLOps Pipeline - Step 1: Preprocess raw data
"""

import argparse
import os
import logging
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
import mlflow

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def parse_args():
    parser = argparse.ArgumentParser("preprocess")
    parser.add_argument("--raw_data",       type=str, help="Path to raw input data")
    parser.add_argument("--train_data",     type=str, help="Path to output train data")
    parser.add_argument("--test_data",      type=str, help="Path to output test data")
    parser.add_argument("--test_size",      type=float, default=0.2)
    parser.add_argument("--random_state",   type=int, default=42)
    return parser.parse_args()


def load_data(path: str) -> pd.DataFrame:
    """Load CSV data from the given path."""
    files = [f for f in os.listdir(path) if f.endswith(".csv")]
    if not files:
        raise FileNotFoundError(f"No CSV files found in {path}")
    df = pd.read_csv(os.path.join(path, files[0]))
    logger.info(f"Loaded data: {df.shape[0]} rows, {df.shape[1]} columns")
    return df


def preprocess(df: pd.DataFrame) -> pd.DataFrame:
    """Clean and encode the dataframe."""
    # Drop duplicates
    before = len(df)
    df = df.drop_duplicates()
    logger.info(f"Removed {before - len(df)} duplicate rows")

    # Fill missing numerics with median, categoricals with mode
    for col in df.select_dtypes(include=[np.number]).columns:
        df[col].fillna(df[col].median(), inplace=True)
    for col in df.select_dtypes(include=["object"]).columns:
        df[col].fillna(df[col].mode()[0], inplace=True)

    # Encode categorical columns (except target 'label')
    le = LabelEncoder()
    for col in df.select_dtypes(include=["object"]).columns:
        if col != "label":
            df[col] = le.fit_transform(df[col].astype(str))

    # Scale numeric features (except target)
    feature_cols = [c for c in df.select_dtypes(include=[np.number]).columns if c != "label"]
    scaler = StandardScaler()
    df[feature_cols] = scaler.fit_transform(df[feature_cols])

    logger.info(f"Preprocessing complete. Final shape: {df.shape}")
    return df


def main():
    args = parse_args()
    mlflow.start_run()

    df = load_data(args.raw_data)
    df = preprocess(df)

    train_df, test_df = train_test_split(
        df, test_size=args.test_size, random_state=args.random_state, stratify=df.get("label")
    )

    os.makedirs(args.train_data, exist_ok=True)
    os.makedirs(args.test_data, exist_ok=True)

    train_df.to_csv(os.path.join(args.train_data, "train.csv"), index=False)
    test_df.to_csv(os.path.join(args.test_data, "test.csv"), index=False)

    mlflow.log_params({
        "test_size": args.test_size,
        "random_state": args.random_state,
        "train_rows": len(train_df),
        "test_rows": len(test_df),
        "features": len(df.columns) - 1,
    })

    logger.info(f"Train: {len(train_df)} rows | Test: {len(test_df)} rows")
    mlflow.end_run()


if __name__ == "__main__":
    main()
