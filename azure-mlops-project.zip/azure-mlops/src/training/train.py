"""
Model Training Component
Azure ML MLOps Pipeline - Step 2: Train & track model with MLflow
"""

import argparse
import os
import logging
import json
import pandas as pd
import numpy as np
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, f1_score, precision_score,
    recall_score, roc_auc_score, classification_report,
)
import mlflow
import mlflow.sklearn
import joblib

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

MODELS = {
    "gradient_boosting": GradientBoostingClassifier,
    "random_forest": RandomForestClassifier,
    "logistic_regression": LogisticRegression,
}


def parse_args():
    parser = argparse.ArgumentParser("train")
    parser.add_argument("--train_data",       type=str,  required=True)
    parser.add_argument("--model_output",     type=str,  required=True)
    parser.add_argument("--model_type",       type=str,  default="gradient_boosting",
                        choices=list(MODELS.keys()))
    parser.add_argument("--n_estimators",     type=int,  default=100)
    parser.add_argument("--max_depth",        type=int,  default=5)
    parser.add_argument("--learning_rate",    type=float,default=0.1)
    parser.add_argument("--registered_model", type=str,  default="azureml-mlops-model")
    return parser.parse_args()


def load_data(path: str):
    files = [f for f in os.listdir(path) if f.endswith(".csv")]
    df = pd.read_csv(os.path.join(path, files[0]))
    X = df.drop(columns=["label"])
    y = df["label"]
    return X, y


def build_model(model_type: str, **kwargs):
    cls = MODELS[model_type]
    if model_type == "logistic_regression":
        return cls(max_iter=1000, random_state=42)
    elif model_type == "random_forest":
        return cls(
            n_estimators=kwargs.get("n_estimators", 100),
            max_depth=kwargs.get("max_depth", 5),
            random_state=42,
            n_jobs=-1,
        )
    else:  # gradient_boosting
        return cls(
            n_estimators=kwargs.get("n_estimators", 100),
            max_depth=kwargs.get("max_depth", 5),
            learning_rate=kwargs.get("learning_rate", 0.1),
            random_state=42,
        )


def evaluate(model, X, y) -> dict:
    preds = model.predict(X)
    proba = model.predict_proba(X)[:, 1] if hasattr(model, "predict_proba") else preds
    return {
        "accuracy":  round(accuracy_score(y, preds), 4),
        "f1":        round(f1_score(y, preds, average="weighted"), 4),
        "precision": round(precision_score(y, preds, average="weighted", zero_division=0), 4),
        "recall":    round(recall_score(y, preds, average="weighted"), 4),
        "roc_auc":   round(roc_auc_score(y, proba) if len(np.unique(y)) == 2 else 0.0, 4),
    }


def main():
    args = parse_args()

    mlflow.sklearn.autolog(log_model_signatures=True, log_input_examples=True)

    with mlflow.start_run() as run:
        logger.info(f"MLflow Run ID: {run.info.run_id}")

        X_train, y_train = load_data(args.train_data)
        logger.info(f"Training data: {X_train.shape}")

        # Log hyperparameters
        params = {
            "model_type":    args.model_type,
            "n_estimators":  args.n_estimators,
            "max_depth":     args.max_depth,
            "learning_rate": args.learning_rate,
            "train_samples": len(X_train),
            "features":      X_train.shape[1],
        }
        mlflow.log_params(params)

        # Train
        model = build_model(
            args.model_type,
            n_estimators=args.n_estimators,
            max_depth=args.max_depth,
            learning_rate=args.learning_rate,
        )
        logger.info(f"Training {args.model_type}...")
        model.fit(X_train, y_train)

        # Evaluate on training set
        train_metrics = evaluate(model, X_train, y_train)
        mlflow.log_metrics({f"train_{k}": v for k, v in train_metrics.items()})
        logger.info(f"Train metrics: {train_metrics}")

        # Log classification report as artifact
        report = classification_report(y_train, model.predict(X_train))
        report_path = "/tmp/classification_report.txt"
        with open(report_path, "w") as f:
            f.write(report)
        mlflow.log_artifact(report_path, "reports")

        # Save model locally and register in MLflow Model Registry
        os.makedirs(args.model_output, exist_ok=True)
        model_path = os.path.join(args.model_output, "model.pkl")
        joblib.dump(model, model_path)

        mlflow.sklearn.log_model(
            model,
            artifact_path="model",
            registered_model_name=args.registered_model,
        )

        # Save metadata
        metadata = {**params, **train_metrics, "run_id": run.info.run_id}
        with open(os.path.join(args.model_output, "metadata.json"), "w") as f:
            json.dump(metadata, f, indent=2)

        logger.info(f"Model saved to {args.model_output}")
        logger.info("Training complete!")


if __name__ == "__main__":
    main()
