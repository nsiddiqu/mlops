"""
Model Evaluation Component
Azure ML MLOps Pipeline - Step 3: Evaluate model on test set & gate deployment
"""

import argparse
import os
import logging
import json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import (
    accuracy_score, f1_score, precision_score, recall_score,
    roc_auc_score, confusion_matrix, roc_curve, ConfusionMatrixDisplay,
)
import mlflow
import joblib

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def parse_args():
    parser = argparse.ArgumentParser("evaluate")
    parser.add_argument("--model_input",        type=str, required=True)
    parser.add_argument("--test_data",          type=str, required=True)
    parser.add_argument("--evaluation_output",  type=str, required=True)
    parser.add_argument("--accuracy_threshold", type=float, default=0.80)
    parser.add_argument("--f1_threshold",       type=float, default=0.75)
    return parser.parse_args()


def load_model(path: str):
    model_file = os.path.join(path, "model.pkl")
    return joblib.load(model_file)


def load_test_data(path: str):
    files = [f for f in os.listdir(path) if f.endswith(".csv")]
    df = pd.read_csv(os.path.join(path, files[0]))
    return df.drop(columns=["label"]), df["label"]


def plot_confusion_matrix(y_true, y_pred, output_dir: str):
    fig, ax = plt.subplots(figsize=(8, 6))
    cm = confusion_matrix(y_true, y_pred)
    disp = ConfusionMatrixDisplay(confusion_matrix=cm)
    disp.plot(ax=ax, colorbar=True)
    ax.set_title("Confusion Matrix", fontsize=14, fontweight="bold")
    path = os.path.join(output_dir, "confusion_matrix.png")
    fig.savefig(path, bbox_inches="tight", dpi=150)
    plt.close(fig)
    return path


def plot_roc_curve(y_true, y_proba, output_dir: str):
    fpr, tpr, _ = roc_curve(y_true, y_proba)
    auc = roc_auc_score(y_true, y_proba)
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.plot(fpr, tpr, color="#2196F3", lw=2, label=f"AUC = {auc:.4f}")
    ax.plot([0, 1], [0, 1], color="grey", linestyle="--", lw=1)
    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate")
    ax.set_title("ROC Curve", fontsize=14, fontweight="bold")
    ax.legend(loc="lower right")
    path = os.path.join(output_dir, "roc_curve.png")
    fig.savefig(path, bbox_inches="tight", dpi=150)
    plt.close(fig)
    return path


def evaluate_model(model, X_test, y_test) -> dict:
    preds = model.predict(X_test)
    proba = model.predict_proba(X_test)[:, 1] if hasattr(model, "predict_proba") else preds
    is_binary = len(np.unique(y_test)) == 2
    return {
        "test_accuracy":  round(accuracy_score(y_test, preds), 4),
        "test_f1":        round(f1_score(y_test, preds, average="weighted"), 4),
        "test_precision": round(precision_score(y_test, preds, average="weighted", zero_division=0), 4),
        "test_recall":    round(recall_score(y_test, preds, average="weighted"), 4),
        "test_roc_auc":   round(roc_auc_score(y_test, proba) if is_binary else 0.0, 4),
    }, preds, proba


def check_deployment_gate(metrics: dict, acc_thresh: float, f1_thresh: float) -> bool:
    passed = metrics["test_accuracy"] >= acc_thresh and metrics["test_f1"] >= f1_thresh
    status = "✅ PASSED" if passed else "❌ FAILED"
    logger.info(f"Deployment gate {status}")
    logger.info(f"  Accuracy: {metrics['test_accuracy']} (threshold: {acc_thresh})")
    logger.info(f"  F1 Score: {metrics['test_f1']} (threshold: {f1_thresh})")
    return passed


def main():
    args = parse_args()
    os.makedirs(args.evaluation_output, exist_ok=True)

    with mlflow.start_run():
        model = load_model(args.model_input)
        X_test, y_test = load_test_data(args.test_data)
        logger.info(f"Test set: {X_test.shape[0]} samples")

        metrics, preds, proba = evaluate_model(model, X_test, y_test)
        mlflow.log_metrics(metrics)
        logger.info(f"Test metrics: {metrics}")

        # Plots
        cm_path = plot_confusion_matrix(y_test, preds, args.evaluation_output)
        mlflow.log_artifact(cm_path, "evaluation_plots")

        if len(np.unique(y_test)) == 2:
            roc_path = plot_roc_curve(y_test, proba, args.evaluation_output)
            mlflow.log_artifact(roc_path, "evaluation_plots")

        # Deployment gate
        gate_passed = check_deployment_gate(
            metrics, args.accuracy_threshold, args.f1_threshold
        )

        # Write evaluation results
        result = {
            **metrics,
            "deployment_gate_passed": gate_passed,
            "accuracy_threshold":     args.accuracy_threshold,
            "f1_threshold":           args.f1_threshold,
        }
        result_path = os.path.join(args.evaluation_output, "evaluation_results.json")
        with open(result_path, "w") as f:
            json.dump(result, f, indent=2)
        mlflow.log_artifact(result_path, "evaluation")
        mlflow.log_param("deployment_approved", gate_passed)

        if not gate_passed:
            raise ValueError(
                f"Model did not meet deployment thresholds. "
                f"Accuracy={metrics['test_accuracy']} (need {args.accuracy_threshold}), "
                f"F1={metrics['test_f1']} (need {args.f1_threshold})"
            )

        logger.info("Evaluation complete — model approved for deployment.")


if __name__ == "__main__":
    main()
