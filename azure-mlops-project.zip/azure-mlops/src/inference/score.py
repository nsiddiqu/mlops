"""
Inference / Scoring Script
Azure ML MLOps Pipeline - Step 4: Real-time endpoint inference

This file is used by Azure ML Managed Online Endpoints.
Azure ML calls init() once at startup, then score() for each request.
"""

import os
import json
import logging
import numpy as np
import pandas as pd
import joblib
import mlflow

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

model = None          # global model reference
feature_names = None  # stored during init


# ──────────────────────────────────────────────
# Azure ML lifecycle hooks
# ──────────────────────────────────────────────

def init():
    """Load model from the AZUREML_MODEL_DIR environment variable."""
    global model, feature_names

    model_dir = os.environ.get("AZUREML_MODEL_DIR", ".")
    model_path = os.path.join(model_dir, "model", "model.pkl")

    # Fallback: try MLflow flavour directory layout
    if not os.path.exists(model_path):
        model_path = os.path.join(model_dir, "model.pkl")

    logger.info(f"Loading model from: {model_path}")
    model = joblib.load(model_path)

    # Try to load feature names from metadata
    metadata_path = os.path.join(model_dir, "model", "metadata.json")
    if os.path.exists(metadata_path):
        with open(metadata_path) as f:
            meta = json.load(f)
        feature_names = meta.get("feature_names")

    logger.info("Model loaded successfully.")


def score(raw_data: str) -> str:
    """
    Score incoming request data.

    Expected input formats
    ----------------------
    Single instance (dict):
        {"feature1": 0.5, "feature2": 1.2, ...}

    Batch (list of dicts):
        [{"feature1": 0.5, ...}, {"feature1": 0.3, ...}]

    Azure ML standard format:
        {"data": [[0.5, 1.2, ...], [0.3, 0.8, ...]]}

    Returns JSON string with predictions and probabilities.
    """
    global model, feature_names

    try:
        payload = json.loads(raw_data)

        # ── Parse various input shapes ──────────────────────
        if isinstance(payload, dict) and "data" in payload:
            data = payload["data"]
            if isinstance(data[0], list):
                X = pd.DataFrame(data, columns=feature_names)
            else:
                X = pd.DataFrame([data], columns=feature_names)

        elif isinstance(payload, list):
            X = pd.DataFrame(payload)

        elif isinstance(payload, dict):
            X = pd.DataFrame([payload])

        else:
            raise ValueError(f"Unsupported payload format: {type(payload)}")

        # Ensure column order matches training
        if feature_names:
            missing = set(feature_names) - set(X.columns)
            if missing:
                raise ValueError(f"Missing features: {missing}")
            X = X[feature_names]

        # ── Predict ─────────────────────────────────────────
        predictions = model.predict(X).tolist()
        result = {"predictions": predictions}

        if hasattr(model, "predict_proba"):
            probabilities = model.predict_proba(X).tolist()
            result["probabilities"] = probabilities
            result["confidence"] = [max(p) for p in probabilities]

        result["num_predictions"] = len(predictions)
        result["status"] = "success"

        return json.dumps(result)

    except Exception as exc:
        logger.error(f"Scoring error: {exc}", exc_info=True)
        return json.dumps({"status": "error", "message": str(exc)})


# ──────────────────────────────────────────────
# Local testing entry point
# ──────────────────────────────────────────────

if __name__ == "__main__":
    # Simulate what Azure ML does at startup
    os.environ.setdefault("AZUREML_MODEL_DIR", "./model_output")
    init()

    # Single prediction
    sample = json.dumps({"feature1": 0.5, "feature2": -0.3, "feature3": 1.2})
    print("Single prediction:", score(sample))

    # Batch prediction (Azure ML standard format)
    batch = json.dumps({"data": [[0.5, -0.3, 1.2], [0.1, 0.8, -0.5]]})
    print("Batch prediction:", score(batch))
