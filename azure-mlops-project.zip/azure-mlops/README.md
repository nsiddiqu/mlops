# Azure ML MLOps — Complete Learning Project

A production-ready MLOps project for learning Azure Machine Learning end-to-end:
**train → track → evaluate → inference → CI/CD deploy**.

---

## Project Structure

```
azure-mlops/
├── src/
│   ├── preprocessing/
│   │   └── preprocess.py        # Step 1 — clean, encode, split data
│   ├── training/
│   │   ├── train.py             # Step 2 — train model + MLflow tracking
│   │   └── evaluate.py          # Step 3 — test set evaluation + deploy gate
│   └── inference/
│       └── score.py             # Step 4 — online endpoint scoring script
├── pipelines/
│   └── pipeline.py              # Azure ML SDK v2 pipeline orchestrator
├── tests/
│   └── test_pipeline.py         # Unit tests (pytest)
├── configs/
│   ├── conda_env.yml            # Conda environment definition
│   └── requirements.txt         # pip requirements
└── .github/workflows/
    └── mlops-cicd.yml           # GitHub Actions CI/CD workflow
```

---

## MLOps Pipeline — Step by Step

### Step 1 — Data Preprocessing (`src/preprocessing/preprocess.py`)
- Removes duplicate rows
- Fills missing values (median for numerics, mode for categoricals)
- Label-encodes categorical features
- Standard-scales numeric features
- Splits into train / test sets
- Logs all parameters to MLflow

### Step 2 — Model Training (`src/training/train.py`)
- Supports three model types: **Gradient Boosting**, **Random Forest**, **Logistic Regression**
- Uses `mlflow.sklearn.autolog()` — automatically logs params, metrics, and model
- Registers the model in the **MLflow Model Registry** (accessible from Azure ML Studio)
- Saves `model.pkl` and `metadata.json` as outputs

### Step 3 — Evaluation & Deployment Gate (`src/training/evaluate.py`)
- Evaluates the model on the held-out test set
- Logs: accuracy, F1, precision, recall, ROC-AUC
- Generates confusion matrix and ROC curve plots as MLflow artifacts
- **Deployment gate**: fails the pipeline (and blocks deployment) if accuracy < threshold OR F1 < threshold

### Step 4 — Online Inference (`src/inference/score.py`)
- Implements Azure ML Managed Online Endpoint lifecycle (`init()` / `score()`)
- Accepts three input formats:
  - Single dict: `{"feature1": 0.5, ...}`
  - List of dicts: `[{"feature1": 0.5}, ...]`
  - Azure ML standard: `{"data": [[0.5, ...], ...]}`
- Returns predictions + probabilities + confidence scores

---

## CI/CD Pipeline — GitHub Actions

The workflow (`.github/workflows/mlops-cicd.yml`) has five jobs:

| Job | Trigger | What it does |
|-----|---------|-------------|
| `lint-and-format` | Every push/PR | Black, isort, Flake8 checks |
| `unit-tests` | Every push/PR | pytest + 80% coverage gate |
| `train-and-evaluate` | Push to main | Submits Azure ML pipeline, streams logs |
| `deploy` | Push to main (gate passed) | Deploys model to Managed Online Endpoint |
| `rollback` | On deploy failure | Restores previous green deployment |

---

## Quick Start

### 1. Install dependencies
```bash
pip install -r configs/requirements.txt
```

### 2. Set up Azure credentials
```bash
# Create a service principal (save the JSON output as AZURE_CREDENTIALS secret)
az ad sp create-for-rbac \
  --name "mlops-sp" \
  --role Contributor \
  --scopes /subscriptions/<your-subscription-id> \
  --sdk-auth
```

### 3. Set GitHub Secrets
Go to your repo → Settings → Secrets → Actions:
- `AZURE_CREDENTIALS` — the service principal JSON from step 2
- `AZURE_SUBSCRIPTION_ID`
- `AZURE_RESOURCE_GROUP`
- `AZURE_ML_WORKSPACE`

### 4. Run tests locally
```bash
pytest tests/ -v --cov=src
```

### 5. Submit the pipeline manually
```bash
python pipelines/pipeline.py \
  --raw_data "azureml:raw-dataset:1" \
  --experiment "my-first-run"
```

### 6. Submit + deploy in one command
```bash
python pipelines/pipeline.py \
  --raw_data "azureml:raw-dataset:1" \
  --deploy
```

---

## Environment Variables Reference

| Variable | Description | Default |
|----------|-------------|---------|
| `AZURE_SUBSCRIPTION_ID` | Azure subscription ID | (required) |
| `AZURE_RESOURCE_GROUP` | Resource group name | (required) |
| `AZURE_ML_WORKSPACE` | Azure ML workspace name | (required) |
| `AZURE_ML_COMPUTE` | Compute cluster name | `cpu-cluster` |
| `AZURE_ML_ENDPOINT` | Online endpoint name | `mlops-endpoint` |

---

## Data Format

Your raw CSV must have a column named `label` (binary: 0 or 1) plus any number of feature columns.
All other columns are treated as features automatically.

---

## MLflow Tracking

All runs are tracked in **Azure ML Experiments**. View them in Azure ML Studio:
1. Go to your workspace → Experiments
2. Click the experiment name (default: `mlops-experiment`)
3. Compare runs, view metrics, download artifacts, register models

---

## Learning Checklist

- [ ] Run unit tests and understand each test case
- [ ] Submit a pipeline run via `pipeline.py` and watch it in Azure ML Studio
- [ ] Open an MLflow run and explore the logged metrics and artifacts
- [ ] Change the model type (e.g. `--model_type random_forest`) and compare runs
- [ ] Lower the deployment gate threshold and observe a successful deployment
- [ ] Trigger the GitHub Actions workflow by pushing to `main`
- [ ] Invoke the deployed endpoint with a curl or Python request
- [ ] Simulate a rollback by intentionally failing the smoke test
