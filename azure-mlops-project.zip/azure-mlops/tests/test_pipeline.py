"""
Unit Tests — Azure ML MLOps Project
Tests: preprocessing, training, evaluation, and inference scorer
"""

import json
import os
import sys
import pytest
import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier
import joblib

# Make src importable
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.preprocessing.preprocess import preprocess
from src.training.train import build_model, evaluate
from src.training.evaluate import check_deployment_gate


# ──────────────────────────────────────────────────────────────────────────────
# Fixtures
# ──────────────────────────────────────────────────────────────────────────────

@pytest.fixture
def sample_df():
    """Small labelled DataFrame with mixed types."""
    np.random.seed(42)
    n = 200
    return pd.DataFrame({
        "feature1": np.random.randn(n),
        "feature2": np.random.randn(n),
        "feature3": np.random.choice(["A", "B", "C"], n),
        "feature4": np.random.randn(n),
        "label":    np.random.randint(0, 2, n),
    })


@pytest.fixture
def dirty_df(sample_df):
    """DataFrame with duplicates and NaNs injected."""
    df = pd.concat([sample_df, sample_df.iloc[:10]], ignore_index=True)  # duplicates
    df.loc[0:5, "feature1"] = np.nan                                       # NaNs
    df.loc[10:15, "feature3"] = np.nan
    return df


@pytest.fixture
def trained_model(sample_df):
    """Pre-trained GBT model for downstream tests."""
    df = preprocess(sample_df.copy())
    X = df.drop(columns=["label"])
    y = df["label"]
    model = GradientBoostingClassifier(n_estimators=10, random_state=42)
    model.fit(X, y)
    return model, X, y


# ──────────────────────────────────────────────────────────────────────────────
# Preprocessing tests
# ──────────────────────────────────────────────────────────────────────────────

class TestPreprocessing:
    def test_removes_duplicates(self, dirty_df):
        result = preprocess(dirty_df.copy())
        assert len(result) <= len(dirty_df)
        assert result.duplicated().sum() == 0

    def test_fills_missing_numeric(self, dirty_df):
        result = preprocess(dirty_df.copy())
        assert result.select_dtypes(include=[np.number]).isnull().sum().sum() == 0

    def test_fills_missing_categorical(self, dirty_df):
        result = preprocess(dirty_df.copy())
        assert result.isnull().sum().sum() == 0

    def test_encodes_categoricals(self, sample_df):
        result = preprocess(sample_df.copy())
        for col in result.columns:
            assert result[col].dtype != object, f"Column {col} is still object type"

    def test_output_shape(self, sample_df):
        result = preprocess(sample_df.copy())
        assert result.shape[1] == sample_df.shape[1]  # same number of columns
        assert len(result) <= len(sample_df)

    def test_label_column_preserved(self, sample_df):
        result = preprocess(sample_df.copy())
        assert "label" in result.columns

    def test_numeric_features_scaled(self, sample_df):
        result = preprocess(sample_df.copy())
        feature1_std = result["feature1"].std()
        # After StandardScaler, std should be close to 1
        assert 0.5 < feature1_std < 2.0


# ──────────────────────────────────────────────────────────────────────────────
# Model building tests
# ──────────────────────────────────────────────────────────────────────────────

class TestModelBuilding:
    @pytest.mark.parametrize("model_type", ["gradient_boosting", "random_forest", "logistic_regression"])
    def test_build_model_types(self, model_type):
        model = build_model(model_type, n_estimators=10, max_depth=3, learning_rate=0.1)
        assert hasattr(model, "fit")
        assert hasattr(model, "predict")

    def test_model_trains(self, sample_df):
        df = preprocess(sample_df.copy())
        X, y = df.drop(columns=["label"]), df["label"]
        model = build_model("gradient_boosting", n_estimators=10, max_depth=3)
        model.fit(X, y)
        preds = model.predict(X)
        assert len(preds) == len(y)
        assert set(preds).issubset({0, 1})

    def test_evaluate_returns_all_metrics(self, trained_model):
        model, X, y = trained_model
        metrics = evaluate(model, X, y)
        for key in ["accuracy", "f1", "precision", "recall", "roc_auc"]:
            assert key in metrics
            assert 0.0 <= metrics[key] <= 1.0

    def test_train_accuracy_above_random(self, trained_model):
        model, X, y = trained_model
        metrics = evaluate(model, X, y)
        # A trained model should beat random (0.5) on its training set
        assert metrics["accuracy"] > 0.5


# ──────────────────────────────────────────────────────────────────────────────
# Evaluation / deployment gate tests
# ──────────────────────────────────────────────────────────────────────────────

class TestDeploymentGate:
    def test_gate_passes_when_above_threshold(self):
        metrics = {"test_accuracy": 0.90, "test_f1": 0.88}
        assert check_deployment_gate(metrics, acc_thresh=0.80, f1_thresh=0.75) is True

    def test_gate_fails_on_low_accuracy(self):
        metrics = {"test_accuracy": 0.70, "test_f1": 0.80}
        assert check_deployment_gate(metrics, acc_thresh=0.80, f1_thresh=0.75) is False

    def test_gate_fails_on_low_f1(self):
        metrics = {"test_accuracy": 0.85, "test_f1": 0.60}
        assert check_deployment_gate(metrics, acc_thresh=0.80, f1_thresh=0.75) is False

    def test_gate_fails_when_both_low(self):
        metrics = {"test_accuracy": 0.50, "test_f1": 0.50}
        assert check_deployment_gate(metrics, acc_thresh=0.80, f1_thresh=0.75) is False

    def test_gate_passes_exactly_at_threshold(self):
        metrics = {"test_accuracy": 0.80, "test_f1": 0.75}
        assert check_deployment_gate(metrics, acc_thresh=0.80, f1_thresh=0.75) is True


# ──────────────────────────────────────────────────────────────────────────────
# Inference scorer tests
# ──────────────────────────────────────────────────────────────────────────────

class TestInferenceScorer:
    def setup_method(self, tmp_path=None):
        """Create a temporary model dir and load the scorer."""
        import tempfile
        self.model_dir = tempfile.mkdtemp()
        os.environ["AZUREML_MODEL_DIR"] = self.model_dir

        # Build & save a simple model
        np.random.seed(0)
        X = pd.DataFrame({"f1": np.random.randn(100), "f2": np.random.randn(100), "f3": np.random.randn(100)})
        y = np.random.randint(0, 2, 100)
        model = GradientBoostingClassifier(n_estimators=10, random_state=0)
        model.fit(X, y)
        joblib.dump(model, os.path.join(self.model_dir, "model.pkl"))

    def test_score_single_dict(self):
        from src.inference.score import init, score
        init()
        result = json.loads(score(json.dumps({"f1": 0.5, "f2": -0.3, "f3": 1.2})))
        assert result["status"] == "success"
        assert "predictions" in result
        assert len(result["predictions"]) == 1

    def test_score_batch_list(self):
        from src.inference.score import init, score
        init()
        batch = [{"f1": 0.5, "f2": -0.3, "f3": 1.2}, {"f1": 0.1, "f2": 0.8, "f3": -0.5}]
        result = json.loads(score(json.dumps(batch)))
        assert result["status"] == "success"
        assert result["num_predictions"] == 2

    def test_score_azure_ml_format(self):
        from src.inference.score import init, score
        init()
        payload = json.dumps({"data": [[0.5, -0.3, 1.2], [0.1, 0.8, -0.5]]})
        result = json.loads(score(payload))
        assert result["status"] == "success"
        assert result["num_predictions"] == 2

    def test_score_returns_probabilities(self):
        from src.inference.score import init, score
        init()
        result = json.loads(score(json.dumps({"f1": 0.5, "f2": -0.3, "f3": 1.2})))
        assert "probabilities" in result
        probs = result["probabilities"][0]
        assert abs(sum(probs) - 1.0) < 1e-6   # should sum to 1

    def test_score_returns_error_on_bad_input(self):
        from src.inference.score import init, score
        init()
        result = json.loads(score("not valid json{{"))
        assert result["status"] == "error"
