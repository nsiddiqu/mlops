"""
Azure ML Pipeline Definition
Azure ML MLOps - Orchestrates: preprocess → train → evaluate → (register model)

Uses Azure ML SDK v2 (azure-ai-ml).
Run locally:  python pipelines/pipeline.py
Run in CI/CD: triggered by GitHub Actions workflow.
"""

import os
import argparse
from azure.ai.ml import MLClient, Input, Output
from azure.ai.ml.dsl import pipeline
from azure.ai.ml import command
from azure.ai.ml.entities import (
    AmlCompute, Environment, BuildContext,
    ManagedOnlineEndpoint, ManagedOnlineDeployment, Model,
)
from azure.ai.ml.constants import AssetTypes
from azure.identity import DefaultAzureCredential
from azure.ai.ml.sweep import Choice, Uniform


# ──────────────────────────────────────────────────────────────────────────────
# Configuration  (override with env vars in CI/CD)
# ──────────────────────────────────────────────────────────────────────────────
SUBSCRIPTION_ID  = os.environ.get("AZURE_SUBSCRIPTION_ID", "<your-subscription-id>")
RESOURCE_GROUP   = os.environ.get("AZURE_RESOURCE_GROUP",  "<your-resource-group>")
WORKSPACE_NAME   = os.environ.get("AZURE_ML_WORKSPACE",    "<your-workspace>")
COMPUTE_NAME     = os.environ.get("AZURE_ML_COMPUTE",      "cpu-cluster")
ENDPOINT_NAME    = os.environ.get("AZURE_ML_ENDPOINT",     "mlops-endpoint")
ENV_NAME         = "mlops-env"
REGISTERED_MODEL = "azureml-mlops-model"


# ──────────────────────────────────────────────────────────────────────────────
# Azure ML Client
# ──────────────────────────────────────────────────────────────────────────────

def get_client() -> MLClient:
    credential = DefaultAzureCredential()
    return MLClient(credential, SUBSCRIPTION_ID, RESOURCE_GROUP, WORKSPACE_NAME)


# ──────────────────────────────────────────────────────────────────────────────
# Compute cluster (idempotent)
# ──────────────────────────────────────────────────────────────────────────────

def ensure_compute(ml_client: MLClient):
    try:
        ml_client.compute.get(COMPUTE_NAME)
        print(f"Compute '{COMPUTE_NAME}' already exists.")
    except Exception:
        print(f"Creating compute cluster '{COMPUTE_NAME}'...")
        cluster = AmlCompute(
            name=COMPUTE_NAME,
            type="amlcompute",
            size="Standard_DS3_v2",
            min_instances=0,
            max_instances=4,
            idle_time_before_scale_down=120,
            tier="Dedicated",
        )
        ml_client.compute.begin_create_or_update(cluster).result()
        print("Compute cluster created.")


# ──────────────────────────────────────────────────────────────────────────────
# Environment
# ──────────────────────────────────────────────────────────────────────────────

def ensure_environment(ml_client: MLClient) -> str:
    env = Environment(
        name=ENV_NAME,
        description="MLOps training & evaluation environment",
        conda_file="configs/conda_env.yml",
        image="mcr.microsoft.com/azureml/openmpi4.1.0-ubuntu20.04",
    )
    created = ml_client.environments.create_or_update(env)
    return f"{created.name}:{created.version}"


# ──────────────────────────────────────────────────────────────────────────────
# Component definitions
# ──────────────────────────────────────────────────────────────────────────────

def make_preprocess_component(env_version: str):
    return command(
        name="preprocess",
        display_name="Data Preprocessing",
        description="Clean, encode, scale and split raw data",
        inputs={
            "raw_data":     Input(type=AssetTypes.URI_FOLDER),
            "test_size":    Input(type="number", default=0.2),
            "random_state": Input(type="integer", default=42),
        },
        outputs={
            "train_data": Output(type=AssetTypes.URI_FOLDER, mode="rw_mount"),
            "test_data":  Output(type=AssetTypes.URI_FOLDER, mode="rw_mount"),
        },
        code="./src/preprocessing",
        command=(
            "python preprocess.py "
            "--raw_data ${{inputs.raw_data}} "
            "--train_data ${{outputs.train_data}} "
            "--test_data ${{outputs.test_data}} "
            "--test_size ${{inputs.test_size}} "
            "--random_state ${{inputs.random_state}}"
        ),
        environment=f"azureml:{env_version}",
        compute=COMPUTE_NAME,
    )


def make_train_component(env_version: str):
    return command(
        name="train",
        display_name="Model Training",
        description="Train model with MLflow experiment tracking",
        inputs={
            "train_data":       Input(type=AssetTypes.URI_FOLDER),
            "model_type":       Input(type="string", default="gradient_boosting"),
            "n_estimators":     Input(type="integer", default=100),
            "max_depth":        Input(type="integer", default=5),
            "learning_rate":    Input(type="number", default=0.1),
            "registered_model": Input(type="string", default=REGISTERED_MODEL),
        },
        outputs={
            "model_output": Output(type=AssetTypes.URI_FOLDER, mode="rw_mount"),
        },
        code="./src/training",
        command=(
            "python train.py "
            "--train_data ${{inputs.train_data}} "
            "--model_output ${{outputs.model_output}} "
            "--model_type ${{inputs.model_type}} "
            "--n_estimators ${{inputs.n_estimators}} "
            "--max_depth ${{inputs.max_depth}} "
            "--learning_rate ${{inputs.learning_rate}} "
            "--registered_model ${{inputs.registered_model}}"
        ),
        environment=f"azureml:{env_version}",
        compute=COMPUTE_NAME,
    )


def make_evaluate_component(env_version: str):
    return command(
        name="evaluate",
        display_name="Model Evaluation & Gate",
        description="Evaluate model on test set; fail pipeline if thresholds not met",
        inputs={
            "model_input":        Input(type=AssetTypes.URI_FOLDER),
            "test_data":          Input(type=AssetTypes.URI_FOLDER),
            "accuracy_threshold": Input(type="number", default=0.80),
            "f1_threshold":       Input(type="number", default=0.75),
        },
        outputs={
            "evaluation_output": Output(type=AssetTypes.URI_FOLDER, mode="rw_mount"),
        },
        code="./src/training",
        command=(
            "python evaluate.py "
            "--model_input ${{inputs.model_input}} "
            "--test_data ${{inputs.test_data}} "
            "--evaluation_output ${{outputs.evaluation_output}} "
            "--accuracy_threshold ${{inputs.accuracy_threshold}} "
            "--f1_threshold ${{inputs.f1_threshold}}"
        ),
        environment=f"azureml:{env_version}",
        compute=COMPUTE_NAME,
    )


# ──────────────────────────────────────────────────────────────────────────────
# Pipeline graph
# ──────────────────────────────────────────────────────────────────────────────

def build_pipeline(raw_data_path: str, env_version: str):
    preprocess_step = make_preprocess_component(env_version)
    train_step      = make_train_component(env_version)
    evaluate_step   = make_evaluate_component(env_version)

    @pipeline(
        name="mlops_training_pipeline",
        description="End-to-end MLOps: preprocess → train → evaluate",
        tags={"project": "azure-mlops", "framework": "sklearn"},
    )
    def mlops_pipeline(raw_data: Input(type=AssetTypes.URI_FOLDER)):
        preprocess = preprocess_step(raw_data=raw_data)

        train = train_step(
            train_data=preprocess.outputs.train_data,
        )

        evaluate = evaluate_step(
            model_input=train.outputs.model_output,
            test_data=preprocess.outputs.test_data,
        )
        return {
            "trained_model":      train.outputs.model_output,
            "evaluation_results": evaluate.outputs.evaluation_output,
        }

    return mlops_pipeline(raw_data=Input(type=AssetTypes.URI_FOLDER, path=raw_data_path))


# ──────────────────────────────────────────────────────────────────────────────
# Deployment
# ──────────────────────────────────────────────────────────────────────────────

def deploy_model(ml_client: MLClient, model_name: str, endpoint_name: str):
    """Create or update a Managed Online Endpoint with the latest model version."""
    print(f"Deploying model '{model_name}' to endpoint '{endpoint_name}'...")

    # Get latest registered model version
    latest_model = list(ml_client.models.list(name=model_name))[0]
    print(f"  Model version: {latest_model.version}")

    # Ensure endpoint exists
    try:
        ml_client.online_endpoints.get(endpoint_name)
    except Exception:
        endpoint = ManagedOnlineEndpoint(
            name=endpoint_name,
            description="MLOps model online endpoint",
            auth_mode="key",
            tags={"model": model_name},
        )
        ml_client.online_endpoints.begin_create_or_update(endpoint).result()
        print("  Endpoint created.")

    # Create deployment
    deployment = ManagedOnlineDeployment(
        name="blue",
        endpoint_name=endpoint_name,
        model=latest_model.id,
        code_configuration={
            "code": "./src/inference",
            "scoring_script": "score.py",
        },
        environment=f"azureml:{ENV_NAME}:latest",
        instance_type="Standard_DS2_v2",
        instance_count=1,
    )
    ml_client.online_deployments.begin_create_or_update(deployment).result()

    # Route 100 % traffic to blue
    endpoint = ml_client.online_endpoints.get(endpoint_name)
    endpoint.traffic = {"blue": 100}
    ml_client.online_endpoints.begin_create_or_update(endpoint).result()
    print(f"  Deployment complete. Endpoint: {endpoint_name}")


# ──────────────────────────────────────────────────────────────────────────────
# Entry point
# ──────────────────────────────────────────────────────────────────────────────

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--raw_data",    type=str, default="azureml:raw-dataset:1")
    p.add_argument("--deploy",      action="store_true", help="Deploy after pipeline")
    p.add_argument("--experiment",  type=str, default="mlops-experiment")
    return p.parse_args()


if __name__ == "__main__":
    args = parse_args()
    ml_client = get_client()

    ensure_compute(ml_client)
    env_version = ensure_environment(ml_client)

    pipeline_job = build_pipeline(args.raw_data, env_version)
    pipeline_job.settings.default_compute     = COMPUTE_NAME
    pipeline_job.settings.default_datastore   = "workspaceblobstore"
    pipeline_job.settings.force_rerun         = True
    pipeline_job.experiment_name              = args.experiment

    submitted = ml_client.jobs.create_or_update(pipeline_job)
    print(f"Pipeline submitted: {submitted.name}")
    print(f"Studio URL: {submitted.studio_url}")

    ml_client.jobs.stream(submitted.name)   # tail logs

    if args.deploy:
        deploy_model(ml_client, REGISTERED_MODEL, ENDPOINT_NAME)
